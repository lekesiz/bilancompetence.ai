import { Home, Users, BarChart3, Calendar, Brain, FileText, Settings, LogOut } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";

export function AppSidebar() {
  const [location] = useLocation();
  const { user } = useAuth();

  const beneficiaryItems = [
    { title: "Tableau de bord", url: "/", icon: Home },
    { title: "Mon bilan", url: "/my-assessment", icon: FileText },
    { title: "Mes compétences", url: "/skills", icon: Brain },
    { title: "Séances", url: "/sessions", icon: Calendar },
  ];

  const consultantItems = [
    { title: "Tableau de bord", url: "/consultant", icon: Home },
    { title: "Mes bilans", url: "/consultant/assessments", icon: FileText },
    { title: "Calendrier", url: "/consultant/calendar", icon: Calendar },
    { title: "Analyse IA", url: "/consultant/ai-analysis", icon: Brain },
  ];

  const adminItems = [
    { title: "Vue d'ensemble", url: "/admin", icon: Home },
    { title: "Tous les bilans", url: "/admin/assessments", icon: FileText },
    { title: "Consultants", url: "/admin/consultants", icon: Users },
    { title: "Statistiques", url: "/admin/analytics", icon: BarChart3 },
  ];

  const items = user?.role === 'consultant' 
    ? consultantItems 
    : user?.role === 'admin'
    ? adminItems
    : beneficiaryItems;

  const userInitials = user?.firstName && user?.lastName
    ? `${user.firstName.charAt(0)}${user.lastName.charAt(0)}`.toUpperCase()
    : user?.email?.charAt(0).toUpperCase() || "U";

  return (
    <Sidebar>
      <SidebarHeader className="border-b border-sidebar-border p-6">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Brain className="h-6 w-6" />
          </div>
          <div>
            <h2 className="text-lg font-semibold">BilanCompetence.AI</h2>
            <p className="text-xs text-muted-foreground">
              {user?.role === 'consultant' && 'Espace consultant'}
              {user?.role === 'admin' && 'Administration'}
              {user?.role === 'beneficiary' && 'Espace bénéficiaire'}
            </p>
          </div>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild isActive={location === item.url} data-testid={`link-${item.url}`}>
                    <Link href={item.url}>
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="border-t border-sidebar-border p-4">
        <div className="flex items-center gap-3 mb-4">
          <Avatar className="h-10 w-10">
            <AvatarImage src={user?.profileImageUrl || undefined} alt={user?.firstName || "User"} />
            <AvatarFallback>{userInitials}</AvatarFallback>
          </Avatar>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">
              {user?.firstName && user?.lastName 
                ? `${user.firstName} ${user.lastName}` 
                : user?.email}
            </p>
            <p className="text-xs text-muted-foreground truncate">{user?.email}</p>
          </div>
        </div>
        <Button
          variant="outline"
          size="sm"
          className="w-full justify-start"
          onClick={() => window.location.href = "/api/logout"}
          data-testid="button-logout"
        >
          <LogOut className="h-4 w-4 mr-2" />
          Déconnexion
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}
