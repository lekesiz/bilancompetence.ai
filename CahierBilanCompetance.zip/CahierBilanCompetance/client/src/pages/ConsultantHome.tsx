import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Users, Calendar, Brain, FileText, TrendingUp, Clock } from "lucide-react";
import { Link } from "wouter";
import type { AssessmentWithRelations } from "@shared/schema";

export default function ConsultantHome() {
  const { data: assessments, isLoading } = useQuery<AssessmentWithRelations[]>({
    queryKey: ["/api/consultant/assessments"],
  });

  const { data: stats } = useQuery<{
    totalActive: number;
    completedThisMonth: number;
    upcomingSessions: number;
    averageProgress: number;
  }>({
    queryKey: ["/api/consultant/stats"],
  });

  const statusColors = {
    pending: "bg-yellow-500/10 text-yellow-700 dark:text-yellow-400",
    in_progress: "bg-blue-500/10 text-blue-700 dark:text-blue-400",
    completed: "bg-green-500/10 text-green-700 dark:text-green-400",
    cancelled: "bg-red-500/10 text-red-700 dark:text-red-400",
  };

  const statusLabels = {
    pending: "En attente",
    in_progress: "En cours",
    completed: "Terminé",
    cancelled: "Annulé",
  };

  const phaseLabels = {
    preliminary: "Préliminaire",
    investigation: "Investigation",
    conclusion: "Conclusion",
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
          <p className="text-sm text-muted-foreground">Chargement...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">Tableau de bord consultant</h1>
        <p className="text-muted-foreground">
          Vue d'ensemble de vos bilans en cours
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Bilans actifs</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">{stats?.totalActive || 0}</div>
              <Users className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Complétés ce mois</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">{stats?.completedThisMonth || 0}</div>
              <TrendingUp className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Séances à venir</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">{stats?.upcomingSessions || 0}</div>
              <Calendar className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardDescription>Progression moyenne</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="text-3xl font-bold">{stats?.averageProgress || 0}%</div>
              <Clock className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Active Assessments */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Bilans en cours</CardTitle>
              <CardDescription>Gérez et suivez vos bilans actifs</CardDescription>
            </div>
            <Button variant="outline" asChild data-testid="button-all-assessments">
              <Link href="/consultant/assessments">
                Voir tous
              </Link>
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {!assessments || assessments.length === 0 ? (
            <div className="text-center py-12">
              <Users className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="font-medium mb-2">Aucun bilan en cours</h3>
              <p className="text-sm text-muted-foreground">
                Les bilans qui vous seront assignés apparaîtront ici
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {assessments.slice(0, 5).map((assessment) => (
                <div
                  key={assessment.id}
                  className="flex items-center justify-between p-4 border rounded-lg hover-elevate"
                >
                  <div className="flex items-center gap-4 flex-1">
                    <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                      <Users className="h-6 w-6 text-primary" />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium">
                        {assessment.beneficiary?.firstName} {assessment.beneficiary?.lastName}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {phaseLabels[assessment.currentPhase]} • {assessment.progressPercentage}% complété
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <Badge className={statusColors[assessment.status]}>
                      {statusLabels[assessment.status]}
                    </Badge>
                    <Button variant="ghost" size="sm" data-testid={`button-view-assessment-${assessment.id}`}>
                      Voir
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="hover-elevate">
          <CardHeader>
            <Calendar className="h-8 w-8 text-primary mb-2" />
            <CardTitle>Calendrier</CardTitle>
            <CardDescription>
              Gérez vos rendez-vous et disponibilités
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" asChild className="w-full" data-testid="button-calendar">
              <Link href="/consultant/calendar">
                Accéder
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader>
            <Brain className="h-8 w-8 text-primary mb-2" />
            <CardTitle>Analyse IA</CardTitle>
            <CardDescription>
              Obtenez des recommandations personnalisées
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" asChild className="w-full" data-testid="button-ai-analysis">
              <Link href="/consultant/ai-analysis">
                Accéder
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader>
            <FileText className="h-8 w-8 text-primary mb-2" />
            <CardTitle>Documents</CardTitle>
            <CardDescription>
              Générez vos synthèses et rapports
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" className="w-full" disabled data-testid="button-documents">
              Bientôt disponible
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
