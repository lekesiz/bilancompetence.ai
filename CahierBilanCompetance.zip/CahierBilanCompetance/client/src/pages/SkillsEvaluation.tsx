import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Plus, Trash2, Heart, Meh, Frown, Save } from "lucide-react";
import type { Skill, InsertSkill } from "@shared/schema";

export default function SkillsEvaluation() {
  const { toast } = useToast();
  const [newSkill, setNewSkill] = useState({
    name: "",
    category: "",
    level: "beginner" as const,
    preference: "neutral" as const,
    context: "",
    frequency: "",
    yearsOfExperience: 0,
  });

  const { data: skills, isLoading } = useQuery<Skill[]>({
    queryKey: ["/api/skills"],
  });

  const addSkillMutation = useMutation({
    mutationFn: async (skill: Partial<InsertSkill>) => {
      return await apiRequest("POST", "/api/skills", skill);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/skills"] });
      toast({
        title: "Compétence ajoutée",
        description: "La compétence a été ajoutée avec succès",
      });
      setNewSkill({
        name: "",
        category: "",
        level: "beginner",
        preference: "neutral",
        context: "",
        frequency: "",
        yearsOfExperience: 0,
      });
    },
    onError: () => {
      toast({
        title: "Erreur",
        description: "Impossible d'ajouter la compétence",
        variant: "destructive",
      });
    },
  });

  const deleteSkillMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/skills/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/skills"] });
      toast({
        title: "Compétence supprimée",
        description: "La compétence a été supprimée avec succès",
      });
    },
  });

  const levelLabels = {
    beginner: "Débutant",
    intermediate: "Intermédiaire",
    advanced: "Avancé",
    expert: "Expert",
  };

  const preferenceIcons = {
    love: <Heart className="h-5 w-5 text-red-500" />,
    neutral: <Meh className="h-5 w-5 text-gray-500" />,
    dislike: <Frown className="h-5 w-5 text-blue-500" />,
  };

  const preferenceLabels = {
    love: "J'aime",
    neutral: "Neutre",
    dislike: "N'aime pas",
  };

  const handleAddSkill = () => {
    if (!newSkill.name.trim()) {
      toast({
        title: "Erreur",
        description: "Le nom de la compétence est requis",
        variant: "destructive",
      });
      return;
    }
    addSkillMutation.mutate(newSkill);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
          <p className="text-sm text-muted-foreground">Chargement...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">Auto-évaluation des compétences</h1>
        <p className="text-muted-foreground">
          Évaluez vos compétences professionnelles et personnelles
        </p>
      </div>

      {/* Add New Skill Card */}
      <Card>
        <CardHeader>
          <CardTitle>Ajouter une compétence</CardTitle>
          <CardDescription>
            Décrivez une compétence que vous maîtrisez ou souhaitez développer
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="skill-name">Nom de la compétence *</Label>
              <Input
                id="skill-name"
                placeholder="Ex: Communication, Gestion de projet..."
                value={newSkill.name}
                onChange={(e) => setNewSkill({ ...newSkill, name: e.target.value })}
                data-testid="input-skill-name"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="skill-category">Catégorie</Label>
              <Input
                id="skill-category"
                placeholder="Ex: Technique, Relationnel, Organisationnel..."
                value={newSkill.category}
                onChange={(e) => setNewSkill({ ...newSkill, category: e.target.value })}
                data-testid="input-skill-category"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="skill-level">Niveau de maîtrise</Label>
              <Select
                value={newSkill.level}
                onValueChange={(value: any) => setNewSkill({ ...newSkill, level: value })}
              >
                <SelectTrigger id="skill-level" data-testid="select-skill-level">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="beginner">Débutant</SelectItem>
                  <SelectItem value="intermediate">Intermédiaire</SelectItem>
                  <SelectItem value="advanced">Avancé</SelectItem>
                  <SelectItem value="expert">Expert</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="skill-preference">Appréciation</Label>
              <Select
                value={newSkill.preference}
                onValueChange={(value: any) => setNewSkill({ ...newSkill, preference: value })}
              >
                <SelectTrigger id="skill-preference" data-testid="select-skill-preference">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="love">J'aime</SelectItem>
                  <SelectItem value="neutral">Neutre</SelectItem>
                  <SelectItem value="dislike">N'aime pas</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="skill-context">Contexte d'acquisition</Label>
              <Input
                id="skill-context"
                placeholder="Ex: Formation, Expérience professionnelle..."
                value={newSkill.context}
                onChange={(e) => setNewSkill({ ...newSkill, context: e.target.value })}
                data-testid="input-skill-context"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="skill-years">Années d'expérience</Label>
              <Input
                id="skill-years"
                type="number"
                min="0"
                placeholder="0"
                value={newSkill.yearsOfExperience}
                onChange={(e) => setNewSkill({ ...newSkill, yearsOfExperience: parseInt(e.target.value) || 0 })}
                data-testid="input-skill-years"
              />
            </div>
          </div>

          <Button onClick={handleAddSkill} disabled={addSkillMutation.isPending} data-testid="button-add-skill">
            <Plus className="mr-2 h-4 w-4" />
            Ajouter la compétence
          </Button>
        </CardContent>
      </Card>

      {/* Skills List */}
      <Card>
        <CardHeader>
          <CardTitle>Mes compétences ({skills?.length || 0})</CardTitle>
          <CardDescription>
            Liste de toutes vos compétences évaluées
          </CardDescription>
        </CardHeader>
        <CardContent>
          {!skills || skills.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground mb-4">Aucune compétence ajoutée</p>
              <p className="text-sm text-muted-foreground">
                Commencez par ajouter vos premières compétences ci-dessus
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {skills.map((skill) => (
                <div
                  key={skill.id}
                  className="flex items-center justify-between p-4 border rounded-lg hover-elevate"
                >
                  <div className="flex items-center gap-4 flex-1">
                    <div className="flex flex-col gap-2 flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-medium">{skill.name}</h3>
                        {skill.category && (
                          <Badge variant="secondary" className="text-xs">
                            {skill.category}
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <span className="font-medium">{levelLabels[skill.level]}</span>
                        </span>
                        {skill.yearsOfExperience && skill.yearsOfExperience > 0 && (
                          <span>{skill.yearsOfExperience} an{skill.yearsOfExperience > 1 ? 's' : ''}</span>
                        )}
                        {skill.context && <span>{skill.context}</span>}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex flex-col items-center gap-1">
                        {preferenceIcons[skill.preference || 'neutral']}
                        <span className="text-xs text-muted-foreground">
                          {preferenceLabels[skill.preference || 'neutral']}
                        </span>
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => deleteSkillMutation.mutate(skill.id)}
                    disabled={deleteSkillMutation.isPending}
                    data-testid={`button-delete-skill-${skill.id}`}
                  >
                    <Trash2 className="h-4 w-4 text-destructive" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
