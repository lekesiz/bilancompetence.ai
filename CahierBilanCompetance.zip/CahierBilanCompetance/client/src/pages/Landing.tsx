import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Brain, Users, BarChart3, Sparkles, CheckCircle, ArrowRight } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-primary/5 to-background pt-20 pb-32">
        <div className="container mx-auto px-4 md:px-8 lg:px-12">
          <div className="mx-auto max-w-4xl text-center">
            <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
              <Sparkles className="h-4 w-4" />
              <span>Plateforme SaaS certifiée Qualiopi</span>
            </div>
            <h1 className="mb-6 text-4xl font-bold tracking-tight sm:text-5xl lg:text-6xl">
              Digitalisez vos bilans de compétences avec l'IA
            </h1>
            <p className="mb-8 text-lg text-muted-foreground sm:text-xl">
              La première plateforme française spécialisée combinant expertise humaine et intelligence artificielle pour des bilans de compétences modernes et conformes.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" onClick={() => window.location.href = "/api/login"} data-testid="button-login">
                <ArrowRight className="mr-2 h-5 w-5" />
                Commencer maintenant
              </Button>
              <Button variant="outline" size="lg" data-testid="button-demo">
                Voir la démo
              </Button>
            </div>
            <div className="mt-12 grid grid-cols-3 gap-8 text-center">
              <div>
                <div className="text-3xl font-bold text-primary">500K+</div>
                <div className="text-sm text-muted-foreground">Bilans par an en France</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-primary">90%</div>
                <div className="text-sm text-muted-foreground">Taux de satisfaction</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-primary">40%</div>
                <div className="text-sm text-muted-foreground">Gain de temps admin</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 md:px-8 lg:px-12">
          <div className="mx-auto max-w-3xl text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Pourquoi choisir BilanCompetence.AI ?</h2>
            <p className="text-lg text-muted-foreground">
              Une solution complète pour les organismes de formation, consultants et bénéficiaires
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="hover-elevate">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <Brain className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Intelligence Artificielle</CardTitle>
                <CardDescription>
                  Analyse des compétences et recommandations personnalisées basées sur le marché de l'emploi
                </CardDescription>
              </CardHeader>
            </Card>
            <Card className="hover-elevate">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <CheckCircle className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Conformité Qualiopi</CardTitle>
                <CardDescription>
                  Indicateurs de qualité intégrés et préparation automatique des audits
                </CardDescription>
              </CardHeader>
            </Card>
            <Card className="hover-elevate">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <Users className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Gestion simplifiée</CardTitle>
                <CardDescription>
                  Suivez plusieurs bilans simultanément avec une interface intuitive et moderne
                </CardDescription>
              </CardHeader>
            </Card>
            <Card className="hover-elevate">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <BarChart3 className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Tableaux de bord</CardTitle>
                <CardDescription>
                  Visualisez vos KPIs et performances en temps réel avec des statistiques détaillées
                </CardDescription>
              </CardHeader>
            </Card>
            <Card className="hover-elevate">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <Sparkles className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Expérience utilisateur</CardTitle>
                <CardDescription>
                  Interface moderne et accessible pour tous les profils, du débutant à l'expert
                </CardDescription>
              </CardHeader>
            </Card>
            <Card className="hover-elevate">
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
                  <ArrowRight className="h-6 w-6 text-primary" />
                </div>
                <CardTitle>Processus guidé</CardTitle>
                <CardDescription>
                  Suivi des 3 phases obligatoires avec génération automatique des documents de synthèse
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary/5">
        <div className="container mx-auto px-4 md:px-8 lg:px-12">
          <div className="mx-auto max-w-3xl text-center">
            <h2 className="text-3xl font-bold mb-4">Prêt à digitaliser vos bilans ?</h2>
            <p className="text-lg text-muted-foreground mb-8">
              Rejoignez les organismes de formation qui ont choisi la modernité
            </p>
            <Button size="lg" onClick={() => window.location.href = "/api/login"} data-testid="button-cta-login">
              <ArrowRight className="mr-2 h-5 w-5" />
              Démarrer gratuitement
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12">
        <div className="container mx-auto px-4 md:px-8 lg:px-12">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-2">
              <Brain className="h-6 w-6 text-primary" />
              <span className="font-semibold">BilanCompetence.AI</span>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2025 BilanCompetence.AI - Tous droits réservés
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
