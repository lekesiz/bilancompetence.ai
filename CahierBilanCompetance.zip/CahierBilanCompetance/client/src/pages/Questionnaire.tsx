import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { Loader2, CheckCircle } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { QuestionnaireWithQuestions, QuestionnaireQuestion } from "@shared/schema";

export default function Questionnaire() {
  const [, params] = useRoute("/questionnaire/:id");
  const questionnaireId = params?.id;
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});

  const { data: questionnaire, isLoading } = useQuery<QuestionnaireWithQuestions>({
    queryKey: ["/api/questionnaires", questionnaireId],
    enabled: !!questionnaireId,
  });

  const { data: activeAssessment } = useQuery({
    queryKey: ["/api/assessments/my-assessment"],
  });

  const createResponseMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/responses", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/responses"] });
      toast({
        title: "Questionnaire complété",
        description: "Vos réponses ont été enregistrées avec succès.",
      });
    },
    onError: () => {
      toast({
        title: "Erreur",
        description: "Impossible d'enregistrer vos réponses.",
        variant: "destructive",
      });
    },
  });

  const createAnswerMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/answers", data);
      return await res.json();
    },
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full">
        <Loader2 className="h-8 w-8 animate-spin" data-testid="loading-spinner" />
      </div>
    );
  }

  if (!questionnaire || !activeAssessment) {
    return (
      <div className="container mx-auto p-6">
        <Card>
          <CardHeader>
            <CardTitle>Questionnaire introuvable</CardTitle>
            <CardDescription>Le questionnaire demandé n'existe pas ou vous n'avez pas d'évaluation active.</CardDescription>
          </CardHeader>
        </Card>
      </div>
    );
  }

  const questions = questionnaire.questions || [];
  const currentQuestion = questions[currentStep];
  const progress = ((currentStep + 1) / questions.length) * 100;

  const handleNext = () => {
    if (currentStep < questions.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleAnswerChange = (questionId: string, value: any) => {
    setAnswers((prev) => ({ ...prev, [questionId]: value }));
  };

  const handleSubmit = async () => {
    try {
      const response = await createResponseMutation.mutateAsync({
        questionnaireId: questionnaire.id,
        assessmentId: activeAssessment.id,
        completed: 1,
        completedAt: new Date().toISOString(),
      });

      for (const question of questions) {
        if (answers[question.id]) {
          await createAnswerMutation.mutateAsync({
            responseId: response.id,
            questionId: question.id,
            answerText: typeof answers[question.id] === 'string' ? answers[question.id] : null,
            answerData: typeof answers[question.id] !== 'string' ? answers[question.id] : null,
          });
        }
      }

      toast({
        title: "Questionnaire complété",
        description: "Vos réponses ont été enregistrées avec succès.",
      });
    } catch (error) {
      toast({
        title: "Erreur",
        description: "Impossible d'enregistrer vos réponses.",
        variant: "destructive",
      });
    }
  };

  const renderQuestionInput = (question: QuestionnaireQuestion) => {
    const value = answers[question.id] || "";

    switch (question.questionType) {
      case "text":
        return (
          <Input
            value={value}
            onChange={(e) => handleAnswerChange(question.id, e.target.value)}
            placeholder="Votre réponse"
            data-testid={`input-question-${question.id}`}
          />
        );

      case "textarea":
        return (
          <Textarea
            value={value}
            onChange={(e) => handleAnswerChange(question.id, e.target.value)}
            placeholder="Votre réponse détaillée"
            rows={5}
            data-testid={`textarea-question-${question.id}`}
          />
        );

      case "radio":
        return (
          <RadioGroup
            value={value}
            onValueChange={(val) => handleAnswerChange(question.id, val)}
            data-testid={`radio-question-${question.id}`}
          >
            {Array.isArray(question.options) && question.options.map((option, idx) => (
              <div key={idx} className="flex items-center space-x-2">
                <RadioGroupItem value={option} id={`${question.id}-${idx}`} data-testid={`radio-option-${idx}`} />
                <label htmlFor={`${question.id}-${idx}`} className="cursor-pointer">
                  {option}
                </label>
              </div>
            ))}
          </RadioGroup>
        );

      case "checkbox":
        const selectedOptions = Array.isArray(value) ? value : [];
        return (
          <div className="space-y-2">
            {Array.isArray(question.options) && question.options.map((option, idx) => (
              <div key={idx} className="flex items-center space-x-2">
                <Checkbox
                  id={`${question.id}-${idx}`}
                  checked={selectedOptions.includes(option)}
                  onCheckedChange={(checked) => {
                    const newValue = checked
                      ? [...selectedOptions, option]
                      : selectedOptions.filter((o) => o !== option);
                    handleAnswerChange(question.id, newValue);
                  }}
                  data-testid={`checkbox-option-${idx}`}
                />
                <label htmlFor={`${question.id}-${idx}`} className="cursor-pointer">
                  {option}
                </label>
              </div>
            ))}
          </div>
        );

      case "scale":
        return (
          <RadioGroup
            value={value}
            onValueChange={(val) => handleAnswerChange(question.id, val)}
            className="flex space-x-4"
            data-testid={`scale-question-${question.id}`}
          >
            {Array.isArray(question.options) && question.options.map((option, idx) => (
              <div key={idx} className="flex flex-col items-center space-y-1">
                <RadioGroupItem value={option} id={`${question.id}-${idx}`} data-testid={`scale-option-${idx}`} />
                <label htmlFor={`${question.id}-${idx}`} className="text-sm cursor-pointer">
                  {option}
                </label>
              </div>
            ))}
          </RadioGroup>
        );

      default:
        return null;
    }
  };

  return (
    <div className="container mx-auto p-6 max-w-3xl">
      <Card>
        <CardHeader>
          <CardTitle data-testid="text-questionnaire-title">{questionnaire.title}</CardTitle>
          <CardDescription>{questionnaire.description}</CardDescription>
          <div className="mt-4">
            <div className="flex justify-between text-sm mb-2">
              <span>Question {currentStep + 1} sur {questions.length}</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <Progress value={progress} data-testid="progress-questionnaire" />
          </div>
        </CardHeader>

        {currentQuestion && (
          <CardContent className="space-y-6">
            <div>
              <h3 className="text-lg font-medium mb-4" data-testid={`text-question-${currentStep}`}>
                {currentQuestion.questionText}
                {currentQuestion.required === 1 && <span className="text-destructive ml-1">*</span>}
              </h3>
              {renderQuestionInput(currentQuestion)}
            </div>
          </CardContent>
        )}

        <CardFooter className="flex justify-between gap-2">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentStep === 0}
            data-testid="button-previous"
          >
            Précédent
          </Button>

          {currentStep < questions.length - 1 ? (
            <Button onClick={handleNext} data-testid="button-next">
              Suivant
            </Button>
          ) : (
            <Button
              onClick={handleSubmit}
              disabled={createResponseMutation.isPending}
              data-testid="button-submit"
            >
              {createResponseMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Enregistrement...
                </>
              ) : (
                <>
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Terminer
                </>
              )}
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
}
