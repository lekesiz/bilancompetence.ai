import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, User } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";

type AssessmentSession = {
  id: string;
  assessmentId: string;
  consultantId: string;
  phase: string;
  scheduledDate: string | null;
  duration: number | null;
  notes: string | null;
  completed: number;
  createdAt: string;
  updatedAt: string;
};

export default function Sessions() {
  const { data: sessions = [], isLoading } = useQuery<AssessmentSession[]>({
    queryKey: ["/api/sessions"],
  });

  const upcomingSessions = sessions.filter(
    (s) => s.scheduledDate && new Date(s.scheduledDate) > new Date() && !s.completed
  );
  const pastSessions = sessions.filter(
    (s) => s.completed || (s.scheduledDate && new Date(s.scheduledDate) <= new Date())
  );

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin h-12 w-12 border-4 border-primary border-t-transparent rounded-full"></div>
          <p className="text-muted-foreground">Chargement...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container max-w-6xl mx-auto p-6 space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">Mes séances</h1>
        <p className="text-muted-foreground">
          Consultez vos rendez-vous avec votre consultant
        </p>
      </div>

      <div className="space-y-6">
        <div>
          <h2 className="text-xl font-semibold mb-4">
            Séances à venir ({upcomingSessions.length})
          </h2>
          {upcomingSessions.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center text-muted-foreground">
                Aucune séance planifiée pour le moment
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {upcomingSessions.map((session) => (
                <Card key={session.id} className="hover-elevate" data-testid={`session-${session.id}`}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          <Calendar className="h-5 w-5 text-primary" />
                          {session.scheduledDate &&
                            format(new Date(session.scheduledDate), "EEEE d MMMM yyyy 'à' HH:mm", {
                              locale: fr,
                            })}
                        </CardTitle>
                        <CardDescription className="mt-2 capitalize">
                          Phase : {session.phase}
                        </CardDescription>
                      </div>
                      <Badge variant="default">À venir</Badge>
                    </div>
                  </CardHeader>
                  {(session.duration || session.notes) && (
                    <CardContent className="space-y-2">
                      {session.duration && (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Clock className="h-4 w-4" />
                          Durée : {session.duration} minutes
                        </div>
                      )}
                      {session.notes && (
                        <p className="text-sm bg-muted p-3 rounded-md">{session.notes}</p>
                      )}
                    </CardContent>
                  )}
                </Card>
              ))}
            </div>
          )}
        </div>

        <div>
          <h2 className="text-xl font-semibold mb-4">
            Séances passées ({pastSessions.length})
          </h2>
          {pastSessions.length === 0 ? (
            <Card>
              <CardContent className="p-8 text-center text-muted-foreground">
                Aucune séance passée
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {pastSessions.map((session) => (
                <Card key={session.id} className="opacity-75" data-testid={`session-${session.id}`}>
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          <Calendar className="h-5 w-5 text-muted-foreground" />
                          {session.scheduledDate &&
                            format(new Date(session.scheduledDate), "EEEE d MMMM yyyy 'à' HH:mm", {
                              locale: fr,
                            })}
                        </CardTitle>
                        <CardDescription className="mt-2 capitalize">
                          Phase : {session.phase}
                        </CardDescription>
                      </div>
                      <Badge variant={session.completed ? "secondary" : "outline"}>
                        {session.completed ? "Terminée" : "Passée"}
                      </Badge>
                    </div>
                  </CardHeader>
                  {(session.duration || session.notes) && (
                    <CardContent className="space-y-2">
                      {session.duration && (
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Clock className="h-4 w-4" />
                          Durée : {session.duration} minutes
                        </div>
                      )}
                      {session.notes && (
                        <p className="text-sm bg-muted p-3 rounded-md">{session.notes}</p>
                      )}
                    </CardContent>
                  )}
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
