import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Calendar as CalendarIcon, Clock, Plus, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { fr } from "date-fns/locale";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

type Assessment = {
  id: string;
  beneficiaryId: string;
  consultantId: string;
  currentPhase: string;
  status: string;
  beneficiary?: {
    firstName: string;
    lastName: string;
  };
};

type AssessmentSession = {
  id: string;
  assessmentId: string;
  consultantId: string;
  phase: string;
  scheduledDate: string | null;
  duration: number | null;
  notes: string | null;
  completed: number;
};

export default function ConsultantCalendar() {
  const { toast } = useToast();
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [selectedAssessmentId, setSelectedAssessmentId] = useState("");
  const [selectedPhase, setSelectedPhase] = useState("");
  const [selectedTime, setSelectedTime] = useState("09:00");
  const [duration, setDuration] = useState("60");
  const [notes, setNotes] = useState("");

  const { data: assessments = [] } = useQuery<Assessment[]>({
    queryKey: ["/api/consultant/assessments"],
  });

  const { data: sessions = [] } = useQuery<AssessmentSession[]>({
    queryKey: ["/api/sessions"],
  });

  const createSessionMutation = useMutation({
    mutationFn: async (sessionData: any) => {
      return await apiRequest("POST", "/api/sessions", sessionData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/consultant/stats"] });
      toast({
        title: "Séance créée",
        description: "La séance a été ajoutée au calendrier",
      });
      setIsCreateDialogOpen(false);
      resetForm();
    },
    onError: () => {
      toast({
        title: "Erreur",
        description: "Impossible de créer la séance",
        variant: "destructive",
      });
    },
  });

  const deleteSessionMutation = useMutation({
    mutationFn: async (sessionId: string) => {
      return await apiRequest("DELETE", `/api/sessions/${sessionId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/sessions"] });
      toast({
        title: "Séance supprimée",
        description: "La séance a été retirée du calendrier",
      });
    },
  });

  const resetForm = () => {
    setSelectedAssessmentId("");
    setSelectedPhase("");
    setSelectedTime("09:00");
    setDuration("60");
    setNotes("");
  };

  const handleCreateSession = () => {
    if (!selectedDate || !selectedAssessmentId || !selectedPhase) {
      toast({
        title: "Informations manquantes",
        description: "Veuillez remplir tous les champs obligatoires",
        variant: "destructive",
      });
      return;
    }

    const [hours, minutes] = selectedTime.split(":");
    const scheduledDate = new Date(selectedDate);
    scheduledDate.setHours(parseInt(hours), parseInt(minutes), 0, 0);

    createSessionMutation.mutate({
      assessmentId: selectedAssessmentId,
      phase: selectedPhase,
      scheduledDate: scheduledDate.toISOString(),
      duration: parseInt(duration),
      notes: notes || null,
      completed: 0,
    });
  };

  const sessionsOnSelectedDate = selectedDate
    ? sessions.filter((s) => {
        if (!s.scheduledDate) return false;
        const sessionDate = new Date(s.scheduledDate);
        return (
          sessionDate.getDate() === selectedDate.getDate() &&
          sessionDate.getMonth() === selectedDate.getMonth() &&
          sessionDate.getFullYear() === selectedDate.getFullYear()
        );
      })
    : [];

  const datesWithSessions = sessions
    .filter((s) => s.scheduledDate)
    .map((s) => new Date(s.scheduledDate!));

  return (
    <div className="container max-w-7xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold mb-2">Calendrier des séances</h1>
          <p className="text-muted-foreground">
            Planifiez et gérez vos rendez-vous avec les bénéficiaires
          </p>
        </div>
        <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-create-session">
              <Plus className="mr-2 h-4 w-4" />
              Nouvelle séance
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[500px]">
            <DialogHeader>
              <DialogTitle>Planifier une séance</DialogTitle>
              <DialogDescription>
                Créez un rendez-vous avec un bénéficiaire
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid gap-2">
                <Label htmlFor="assessment">Bénéficiaire *</Label>
                <Select value={selectedAssessmentId} onValueChange={setSelectedAssessmentId}>
                  <SelectTrigger id="assessment" data-testid="select-assessment">
                    <SelectValue placeholder="Sélectionner un bénéficiaire" />
                  </SelectTrigger>
                  <SelectContent>
                    {assessments.map((assessment) => (
                      <SelectItem key={assessment.id} value={assessment.id}>
                        {assessment.beneficiary?.firstName} {assessment.beneficiary?.lastName}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="phase">Phase du bilan *</Label>
                <Select value={selectedPhase} onValueChange={setSelectedPhase}>
                  <SelectTrigger id="phase" data-testid="select-phase">
                    <SelectValue placeholder="Sélectionner une phase" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="preliminary">Préliminaire</SelectItem>
                    <SelectItem value="investigation">Investigation</SelectItem>
                    <SelectItem value="conclusion">Conclusion</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="time">Heure *</Label>
                  <Input
                    id="time"
                    type="time"
                    value={selectedTime}
                    onChange={(e) => setSelectedTime(e.target.value)}
                    data-testid="input-time"
                  />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="duration">Durée (min) *</Label>
                  <Input
                    id="duration"
                    type="number"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    data-testid="input-duration"
                  />
                </div>
              </div>
              <div className="grid gap-2">
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Ajouter des notes pour cette séance..."
                  className="resize-none"
                  rows={3}
                  data-testid="textarea-notes"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                Annuler
              </Button>
              <Button
                onClick={handleCreateSession}
                disabled={createSessionMutation.isPending}
                data-testid="button-confirm-create-session"
              >
                {createSessionMutation.isPending ? "Création..." : "Créer la séance"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Calendrier</CardTitle>
            <CardDescription>Sélectionnez une date pour voir les séances</CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center">
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={setSelectedDate}
              locale={fr}
              className="rounded-md border"
              modifiers={{
                booked: datesWithSessions,
              }}
              modifiersStyles={{
                booked: {
                  fontWeight: "bold",
                  textDecoration: "underline",
                },
              }}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CalendarIcon className="h-5 w-5" />
              {selectedDate && format(selectedDate, "EEEE d MMMM yyyy", { locale: fr })}
            </CardTitle>
            <CardDescription>
              {sessionsOnSelectedDate.length} séance{sessionsOnSelectedDate.length !== 1 ? "s" : ""}{" "}
              planifiée{sessionsOnSelectedDate.length !== 1 ? "s" : ""}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {sessionsOnSelectedDate.length === 0 ? (
              <div className="text-center text-muted-foreground py-8">
                Aucune séance prévue ce jour
              </div>
            ) : (
              sessionsOnSelectedDate
                .sort((a, b) => {
                  if (!a.scheduledDate || !b.scheduledDate) return 0;
                  return new Date(a.scheduledDate).getTime() - new Date(b.scheduledDate).getTime();
                })
                .map((session) => {
                  const assessment = assessments.find((a) => a.id === session.assessmentId);
                  return (
                    <Card key={session.id} className="hover-elevate" data-testid={`session-card-${session.id}`}>
                      <CardContent className="p-4">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <Clock className="h-4 w-4 text-primary" />
                              <span className="font-semibold">
                                {session.scheduledDate &&
                                  format(new Date(session.scheduledDate), "HH:mm")}
                              </span>
                              <Badge variant="secondary" className="capitalize">
                                {session.phase}
                              </Badge>
                            </div>
                            <p className="text-sm font-medium">
                              {assessment?.beneficiary?.firstName}{" "}
                              {assessment?.beneficiary?.lastName}
                            </p>
                            <p className="text-xs text-muted-foreground">
                              Durée : {session.duration} min
                            </p>
                            {session.notes && (
                              <p className="text-sm text-muted-foreground mt-2 bg-muted p-2 rounded">
                                {session.notes}
                              </p>
                            )}
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => deleteSessionMutation.mutate(session.id)}
                            disabled={deleteSessionMutation.isPending}
                            data-testid={`button-delete-session-${session.id}`}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
