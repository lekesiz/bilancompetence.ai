import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Calendar, Brain, FileText, User, Clock, ArrowRight, CheckCircle2, ClipboardList } from "lucide-react";
import { Link } from "wouter";
import type { AssessmentWithRelations, QuestionnaireWithQuestions } from "@shared/schema";

export default function BeneficiaryHome() {
  const { data: assessment, isLoading } = useQuery<AssessmentWithRelations>({
    queryKey: ["/api/assessments/my-assessment"],
  });

  const { data: questionnaires } = useQuery<QuestionnaireWithQuestions[]>({
    queryKey: ["/api/questionnaires?phase=preliminary"],
  });

  const phaseLabels = {
    preliminary: "Phase préliminaire",
    investigation: "Phase d'investigation",
    conclusion: "Phase de conclusion",
  };

  const statusLabels = {
    pending: "En attente",
    in_progress: "En cours",
    completed: "Terminé",
    cancelled: "Annulé",
  };

  const statusColors = {
    pending: "bg-yellow-500/10 text-yellow-700 dark:text-yellow-400",
    in_progress: "bg-blue-500/10 text-blue-700 dark:text-blue-400",
    completed: "bg-green-500/10 text-green-700 dark:text-green-400",
    cancelled: "bg-red-500/10 text-red-700 dark:text-red-400",
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-[calc(100vh-4rem)]">
        <div className="flex flex-col items-center gap-4">
          <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
          <p className="text-sm text-muted-foreground">Chargement...</p>
        </div>
      </div>
    );
  }

  if (!assessment) {
    return (
      <div className="p-8">
        <div className="max-w-3xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Bienvenue sur BilanCompetence.AI</CardTitle>
              <CardDescription>
                Vous n'avez pas encore de bilan de compétences en cours
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="mb-6 text-muted-foreground">
                Un bilan de compétences vous permet de faire le point sur vos compétences, aptitudes et motivations afin de définir un projet professionnel ou de formation.
              </p>
              <Button size="lg" data-testid="button-request-assessment">
                <ArrowRight className="mr-2 h-5 w-5" />
                Demander un bilan
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 space-y-8">
      <div>
        <h1 className="text-3xl font-bold mb-2">Tableau de bord</h1>
        <p className="text-muted-foreground">
          Suivez la progression de votre bilan de compétences
        </p>
      </div>

      {/* Current Assessment Card */}
      <Card className="border-2 border-primary/20">
        <CardHeader>
          <div className="flex items-start justify-between">
            <div>
              <CardTitle className="text-2xl">Mon bilan de compétences</CardTitle>
              <CardDescription className="mt-2">
                {phaseLabels[assessment.currentPhase]}
              </CardDescription>
            </div>
            <Badge className={statusColors[assessment.status]}>
              {statusLabels[assessment.status]}
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Progression globale</span>
              <span className="text-sm text-muted-foreground">{assessment.progressPercentage}%</span>
            </div>
            <Progress value={assessment.progressPercentage} className="h-3" data-testid="progress-assessment" />
          </div>

          {assessment.consultant && (
            <div className="flex items-center gap-3 p-4 bg-muted/50 rounded-lg">
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                <User className="h-6 w-6 text-primary" />
              </div>
              <div>
                <p className="font-medium">
                  {assessment.consultant.firstName} {assessment.consultant.lastName}
                </p>
                <p className="text-sm text-muted-foreground">Votre consultant</p>
              </div>
            </div>
          )}

          {assessment.objectives && (
            <div>
              <h3 className="font-medium mb-2">Objectifs du bilan</h3>
              <p className="text-sm text-muted-foreground">{assessment.objectives}</p>
            </div>
          )}

          <div className="flex gap-4">
            <Button asChild className="flex-1" data-testid="button-view-assessment">
              <Link href="/my-assessment">
                <FileText className="mr-2 h-4 w-4" />
                Voir le détail
              </Link>
            </Button>
            <Button variant="outline" asChild className="flex-1" data-testid="button-view-sessions">
              <Link href="/sessions">
                <Calendar className="mr-2 h-4 w-4" />
                Mes séances
              </Link>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {assessment.currentPhase === 'preliminary' && questionnaires && questionnaires.length > 0 && (
          <Card className="hover-elevate">
            <CardHeader>
              <ClipboardList className="h-8 w-8 text-primary mb-2" />
              <CardTitle>Questionnaire préliminaire</CardTitle>
              <CardDescription>
                Complétez votre auto-évaluation pour commencer
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button variant="outline" asChild className="w-full" data-testid="button-questionnaire">
                <Link href={`/questionnaire/${questionnaires[0].id}`}>
                  Commencer
                </Link>
              </Button>
            </CardContent>
          </Card>
        )}

        <Card className="hover-elevate">
          <CardHeader>
            <Brain className="h-8 w-8 text-primary mb-2" />
            <CardTitle>Auto-évaluation</CardTitle>
            <CardDescription>
              Évaluez vos compétences et préférences professionnelles
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" asChild className="w-full" data-testid="button-skills">
              <Link href="/skills">
                Accéder
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader>
            <Calendar className="h-8 w-8 text-primary mb-2" />
            <CardTitle>Prochaines séances</CardTitle>
            <CardDescription>
              {assessment.sessions && assessment.sessions.length > 0
                ? `${assessment.sessions.length} séance(s) planifiée(s)`
                : "Aucune séance planifiée"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" asChild className="w-full" data-testid="button-calendar">
              <Link href="/sessions">
                Voir le calendrier
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="hover-elevate">
          <CardHeader>
            <FileText className="h-8 w-8 text-primary mb-2" />
            <CardTitle>Documents</CardTitle>
            <CardDescription>
              Accédez à vos documents de synthèse et rapports
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" className="w-full" disabled data-testid="button-documents">
              Bientôt disponible
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Three Phases Progress */}
      <Card>
        <CardHeader>
          <CardTitle>Les 3 phases de votre bilan</CardTitle>
          <CardDescription>
            Le bilan de compétences se déroule en trois phases obligatoires
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-4">
            <div className="flex items-start gap-4 p-4 bg-muted/50 rounded-lg">
              <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                assessment.currentPhase === 'preliminary' ? 'bg-primary text-primary-foreground' : 
                assessment.currentPhase === 'investigation' || assessment.currentPhase === 'conclusion' ? 'bg-green-500 text-white' : 
                'bg-muted text-muted-foreground'
              }`}>
                {assessment.currentPhase === 'investigation' || assessment.currentPhase === 'conclusion' ? (
                  <CheckCircle2 className="h-5 w-5" />
                ) : (
                  <span className="text-sm font-medium">1</span>
                )}
              </div>
              <div className="flex-1">
                <h3 className="font-medium mb-1">Phase préliminaire (2-4 heures)</h3>
                <p className="text-sm text-muted-foreground">
                  Analyse de votre demande et définition des modalités de déroulement
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4 p-4 bg-muted/50 rounded-lg">
              <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                assessment.currentPhase === 'investigation' ? 'bg-primary text-primary-foreground' : 
                assessment.currentPhase === 'conclusion' ? 'bg-green-500 text-white' : 
                'bg-muted text-muted-foreground'
              }`}>
                {assessment.currentPhase === 'conclusion' ? (
                  <CheckCircle2 className="h-5 w-5" />
                ) : (
                  <span className="text-sm font-medium">2</span>
                )}
              </div>
              <div className="flex-1">
                <h3 className="font-medium mb-1">Phase d'investigation (12-20 heures)</h3>
                <p className="text-sm text-muted-foreground">
                  Analyse approfondie de vos compétences, motivations et opportunités professionnelles
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4 p-4 bg-muted/50 rounded-lg">
              <div className={`h-8 w-8 rounded-full flex items-center justify-center ${
                assessment.currentPhase === 'conclusion' ? 'bg-primary text-primary-foreground' : 
                'bg-muted text-muted-foreground'
              }`}>
                {assessment.status === 'completed' ? (
                  <CheckCircle2 className="h-5 w-5" />
                ) : (
                  <span className="text-sm font-medium">3</span>
                )}
              </div>
              <div className="flex-1">
                <h3 className="font-medium mb-1">Phase de conclusion (2-4 heures)</h3>
                <p className="text-sm text-muted-foreground">
                  Synthèse des résultats et élaboration de votre plan d'action personnalisé
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
