# BilanCompetence.AI

## Vue d'ensemble
BilanCompetence.AI est une plateforme SaaS complète pour la digitalisation des bilans de compétences en France. La plateforme propose une authentification multi-rôles (Bénéficiaires, Consultants, Administrateurs Organismes), un workflow d'évaluation en trois phases (Préliminaire, Investigation, Conclusion), une analyse de compétences alimentée par l'IA via OpenAI GPT-4o, une cartographie interactive des compétences, et une interface professionnelle en français.

## Modifications récentes (7 novembre 2025)
- ✅ **Self-Assessment Questionnaires complet** : Système de questionnaires multi-étapes fonctionnel
  - Schéma DB: tables questionnaires, questionnaire_questions, questionnaire_responses, questionnaire_answers
  - Support de 6 types de questions: text, textarea, radio, checkbox, scale_1_5, scale_1_10
  - API sécurisée avec autorisation stricte (GET/POST/PATCH questionnaires, responses, answers)
  - Questionnaire.tsx: formulaire multi-étapes avec navigation, sauvegarde progressive, barre de progression
  - BeneficiaryHome.tsx: carte questionnaire visible en phase préliminaire avec bouton "Commencer"
  - seedQuestionnaires.ts: 10 questions d'auto-évaluation pour phase préliminaire
  - Fix critique: z.coerce.date() pour accepter ISO strings dans completedAt
  - Tests E2E validés: navigation, sauvegarde réponses, complétion avec toast de succès
- ✅ **Session Management sécurisé** : Implémentation complète des endpoints REST avec sécurité renforcée
  - POST /api/sessions : Création avec validation que l'assessment appartient au consultant
  - GET /api/sessions : Liste filtrée par rôle (consultant voit ses sessions, bénéficiaire voit ses rendez-vous)
  - GET /api/sessions/:id : Accès avec vérification d'ownership stricte
  - PATCH /api/sessions/:id : Modification avec validation Zod, ownership checks, prévention de réassignation cross-tenant
  - DELETE /api/sessions/:id : Suppression avec ownership verification
  - Pages frontend: Sessions.tsx (vue bénéficiaire) et ConsultantCalendar.tsx (agenda consultant)
  - Tests E2E réussis : Création, consultation, workflows multi-rôles validés
- ✅ Setup initial: Scripts seed, endpoints API admin/consultant, gestion rôles, utilisateurs de test

## Utilisateurs de test
Les utilisateurs suivants ont été créés pour tester les différents rôles :

### Admin
- ID: `admin-test-001`
- Email: `admin@bilancompetence.ai`
- Nom: Admin Test
- Rôle: Admin
- Accès: Tableau de bord administrateur avec statistiques globales

### Consultant
- ID: `consultant-test-001`
- Email: `consultant@bilancompetence.ai`
- Nom: Marie Dupont
- Rôle: Consultant
- Bio: "Consultante en bilan de compétences avec 10 ans d'expérience"
- Accès: Tableau de bord consultant avec liste des bénéficiaires et statistiques

### Bénéficiaire
- ID: `beneficiary-test-001`
- Email: `beneficiary@bilancompetence.ai`
- Nom: Jean Martin
- Rôle: Bénéficiaire
- Accès: Tableau de bord bénéficiaire avec évaluation de compétences active
- Évaluation créée avec consultant Marie Dupont, phase Investigation, 35% complété
- 3 compétences exemples ajoutées

## Architecture du projet

### Backend (Express + TypeScript)
- **server/db.ts**: Configuration Drizzle ORM avec PostgreSQL (Neon)
- **server/storage.ts**: Interface IStorage et implémentation DbStorage pour accès aux données
- **server/routes.ts**: Tous les endpoints API REST
  - Auth: `/api/auth/user`, `/api/users/:id/role`
  - Assessments: CRUD complet sur `/api/assessments`
  - Sessions: `/api/sessions` (POST/GET/PATCH/DELETE) avec autorisation stricte par rôle
  - Questionnaires: GET `/api/questionnaires` (avec filtre phase), GET `/api/questionnaires/:id`, POST questionnaires/questions (admin)
  - Responses: GET/POST/PATCH `/api/responses` avec ownership checks (beneficiary + consultant read access)
  - Answers: POST/PATCH `/api/answers` avec ownership verification via response chain
  - Consultant: `/api/consultant/assessments`, `/api/consultant/stats`
  - Admin: `/api/admin/stats`, `/api/admin/recent-assessments`
  - Skills: `/api/skills` (GET/POST/DELETE)
  - AI: `/api/ai/analyze-skills`, `/api/ai/career-paths`
- **server/replitAuth.ts**: Authentification Replit Auth (OIDC)
- **server/aiService.ts**: Intégration OpenAI GPT-4o via Replit AI Integrations
- **server/seed.ts**: Script d'initialisation de la base de données

### Frontend (React + Vite + TypeScript)
- **client/src/App.tsx**: Router principal avec SidebarProvider et routes
- **client/src/pages/**:
  - `Landing.tsx`: Page d'accueil publique
  - `BeneficiaryHome.tsx`: Tableau de bord bénéficiaire avec carte questionnaire
  - `ConsultantHome.tsx`: Tableau de bord consultant
  - `AdminHome.tsx`: Tableau de bord administrateur
  - `SkillsEvaluation.tsx`: Interface d'évaluation des compétences
  - `Sessions.tsx`: Vue bénéficiaire des sessions planifiées
  - `Questionnaire.tsx`: Formulaire multi-étapes pour auto-évaluation
  - `ConsultantCalendar.tsx`: Agenda consultant pour planifier rendez-vous
- **client/src/components/app-sidebar.tsx**: Navigation latérale Shadcn
- **client/src/hooks/useAuth.ts**: Hook React Query pour l'authentification
- **design_guidelines.md**: Directives de design (Inter, espacement, couleurs)

### Base de données (shared/schema.ts)
Tables principales :
- **users**: id, email, firstName, lastName, role (beneficiary/consultant/admin), bio
- **assessments**: Bilans avec beneficiaryId, consultantId, phases, statut, objectifs, progression
- **sessions**: Sessions de travail liées aux assessments
- **skills**: Compétences avec nom, catégorie, niveau, préférence, contexte, années d'expérience
- **ai_analyses**: Analyses IA stockées (type, données entrée/sortie, recommandations)
- **questionnaires**: Templates de questionnaires avec title, description, phase, order
- **questionnaire_questions**: Questions individuelles avec type (text/textarea/radio/checkbox/scale), options JSONB
- **questionnaire_responses**: Réponses complètes liées à assessment + questionnaire, avec completedAt
- **questionnaire_answers**: Réponses individuelles aux questions (answerText, answerData JSONB)

Relations :
- assessments.beneficiaryId → users.id
- assessments.consultantId → users.id
- sessions.assessmentId → assessments.id
- skills.assessmentId → assessments.id
- ai_analyses.assessmentId → assessments.id
- questionnaire_questions.questionnaireId → questionnaires.id
- questionnaire_responses.questionnaireId → questionnaires.id
- questionnaire_responses.assessmentId → assessments.id
- questionnaire_responses.beneficiaryId → users.id
- questionnaire_answers.responseId → questionnaire_responses.id
- questionnaire_answers.questionId → questionnaire_questions.id

## Préférences de développement
- Langue: Interface 100% en français avec vouvoiement professionnel
- Design: Esthétique professionnelle inspirée de Linear et Notion
- Typographie: Police Inter exclusivement (Google Fonts)
- Thème: Support du mode sombre via next-themes
- Composants: Shadcn UI avec Radix primitives
- État: React Query (TanStack Query v5) pour toutes les requêtes API
- Formulaires: react-hook-form avec zodResolver pour validation

## Décisions architecturales
- **Storage**: DbStorage avec PostgreSQL (pas de MemStorage) pour persistance réelle
- **Auth**: Replit Auth via OIDC pour gestion multi-rôles
- **AI**: Replit AI Integrations pour OpenAI (pas besoin de clé API)
- **Roles**: Gestion des rôles via endpoint admin PATCH /api/users/:id/role
- **Skills**: assessmentId ajouté côté backend, frontend envoie Partial<InsertSkill>
- **Sessions**: Sécurité multi-couches avec ownership checks, validation Zod, prévention cross-tenant
- **Questionnaires**: Autorisation stricte sur responses/answers, seul le beneficiary owner peut créer/modifier
- **Validation**: Zod schemas générés via drizzle-zod depuis shared/schema.ts
- **Dates**: `z.coerce.date()` pour accepter ISO strings et Dates avec coercion automatique (sessions, responses)

## Commandes utiles
```bash
# Démarrer l'application (déjà configuré dans workflow Replit)
npm run dev

# Pousser le schema vers la base de données
npm run db:push

# Initialiser la base avec des données de test
tsx server/seed.ts

# Ouvrir Drizzle Studio
npm run db:studio
```

## Variables d'environnement
- `DATABASE_URL`: Connexion PostgreSQL (fournie par Replit)
- `SESSION_SECRET`: Secret pour sessions Express (fourni par Replit)
- OpenAI configuré via Replit AI Integrations (pas de variable nécessaire)

## État actuel
✅ Schéma de base de données complet et déployé
✅ Tous les endpoints API implémentés et testés avec sécurité renforcée
✅ Session Management : API REST complète (POST/GET/PATCH/DELETE) avec autorisation stricte
✅ Self-Assessment Questionnaires : Système complet multi-étapes avec 6 types de questions, autorisation tenant-safe
✅ Intégrations configurées (Auth, OpenAI, PostgreSQL)
✅ Design system établi avec guidelines professionnels
✅ Tous les composants frontend construits et connectés
✅ Utilisateurs de test créés avec données exemples + questionnaire seed data
✅ Application fonctionnelle sur port 5000
✅ Tests E2E validés pour workflows multi-rôles (sessions + questionnaires)

## Prochaines étapes
📋 Document Generation & PDF Export
🇫🇷 France Travail API Integration (ROME)
📊 Qualiopi Compliance Tracking
💳 Stripe Payment Integration
📈 Advanced Analytics Dashboard
✍️ Electronic Signature
📧 Email Notification System
🧪 Personality Tests & Professional Interest Assessments
📚 Resource Library
