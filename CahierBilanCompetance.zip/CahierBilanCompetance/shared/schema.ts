import { sql } from 'drizzle-orm';
import { relations } from 'drizzle-orm';
import {
  index,
  integer,
  jsonb,
  pgEnum,
  pgTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Enums
export const userRoleEnum = pgEnum('user_role', ['beneficiary', 'consultant', 'admin']);
export const assessmentPhaseEnum = pgEnum('assessment_phase', ['preliminary', 'investigation', 'conclusion']);
export const assessmentStatusEnum = pgEnum('assessment_status', ['pending', 'in_progress', 'completed', 'cancelled']);
export const skillLevelEnum = pgEnum('skill_level', ['beginner', 'intermediate', 'advanced', 'expert']);
export const skillPreferenceEnum = pgEnum('skill_preference', ['love', 'neutral', 'dislike']);
export const questionTypeEnum = pgEnum('question_type', ['text', 'textarea', 'radio', 'checkbox', 'scale']);

// Session storage table (required for Replit Auth)
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table (required for Replit Auth, extended with role)
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: userRoleEnum("role").notNull().default('beneficiary'),
  organizationName: varchar("organization_name"),
  phoneNumber: varchar("phone_number"),
  bio: text("bio"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const usersRelations = relations(users, ({ many }) => ({
  beneficiaryAssessments: many(assessments, { relationName: 'beneficiaryAssessments' }),
  consultantAssessments: many(assessments, { relationName: 'consultantAssessments' }),
  sessions: many(assessmentSessions),
}));

// Assessments (Bilans)
export const assessments = pgTable("assessments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  beneficiaryId: varchar("beneficiary_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  consultantId: varchar("consultant_id").references(() => users.id, { onDelete: 'set null' }),
  currentPhase: assessmentPhaseEnum("current_phase").notNull().default('preliminary'),
  status: assessmentStatusEnum("status").notNull().default('pending'),
  objectives: text("objectives"),
  startDate: timestamp("start_date"),
  endDate: timestamp("end_date"),
  progressPercentage: integer("progress_percentage").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const assessmentsRelations = relations(assessments, ({ one, many }) => ({
  beneficiary: one(users, {
    fields: [assessments.beneficiaryId],
    references: [users.id],
    relationName: 'beneficiaryAssessments',
  }),
  consultant: one(users, {
    fields: [assessments.consultantId],
    references: [users.id],
    relationName: 'consultantAssessments',
  }),
  sessions: many(assessmentSessions),
  skills: many(skills),
  aiAnalyses: many(aiAnalyses),
}));

// Assessment Sessions (Séances)
export const assessmentSessions = pgTable("assessment_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  assessmentId: varchar("assessment_id").notNull().references(() => assessments.id, { onDelete: 'cascade' }),
  consultantId: varchar("consultant_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  phase: assessmentPhaseEnum("phase").notNull(),
  scheduledDate: timestamp("scheduled_date"),
  duration: integer("duration"),
  notes: text("notes"),
  completed: integer("completed").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const assessmentSessionsRelations = relations(assessmentSessions, ({ one }) => ({
  assessment: one(assessments, {
    fields: [assessmentSessions.assessmentId],
    references: [assessments.id],
  }),
  consultant: one(users, {
    fields: [assessmentSessions.consultantId],
    references: [users.id],
  }),
}));

// Skills (Compétences)
export const skills = pgTable("skills", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  assessmentId: varchar("assessment_id").notNull().references(() => assessments.id, { onDelete: 'cascade' }),
  name: varchar("name").notNull(),
  category: varchar("category"),
  level: skillLevelEnum("level").notNull().default('beginner'),
  preference: skillPreferenceEnum("preference").default('neutral'),
  context: varchar("context"),
  frequency: varchar("frequency"),
  yearsOfExperience: integer("years_of_experience"),
  isTransferable: integer("is_transferable").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const skillsRelations = relations(skills, ({ one }) => ({
  assessment: one(assessments, {
    fields: [skills.assessmentId],
    references: [assessments.id],
  }),
}));

// AI Analyses (Analyses IA)
export const aiAnalyses = pgTable("ai_analyses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  assessmentId: varchar("assessment_id").notNull().references(() => assessments.id, { onDelete: 'cascade' }),
  analysisType: varchar("analysis_type").notNull(),
  inputData: jsonb("input_data"),
  outputData: jsonb("output_data"),
  recommendations: text("recommendations"),
  careerPaths: jsonb("career_paths"),
  transferableSkills: jsonb("transferable_skills"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const aiAnalysesRelations = relations(aiAnalyses, ({ one }) => ({
  assessment: one(assessments, {
    fields: [aiAnalyses.assessmentId],
    references: [assessments.id],
  }),
}));

// Questionnaires (Questionnaires d'auto-évaluation)
export const questionnaires = pgTable("questionnaires", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: varchar("title").notNull(),
  description: text("description"),
  phase: assessmentPhaseEnum("phase").notNull(),
  order: integer("order").notNull().default(0),
  isActive: integer("is_active").notNull().default(1),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const questionnairesRelations = relations(questionnaires, ({ many }) => ({
  questions: many(questionnaireQuestions),
  responses: many(questionnaireResponses),
}));

// Questionnaire Questions
export const questionnaireQuestions = pgTable("questionnaire_questions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  questionnaireId: varchar("questionnaire_id").notNull().references(() => questionnaires.id, { onDelete: 'cascade' }),
  questionText: text("question_text").notNull(),
  questionType: questionTypeEnum("question_type").notNull().default('text'),
  options: jsonb("options"),
  required: integer("required").notNull().default(1),
  order: integer("order").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const questionnaireQuestionsRelations = relations(questionnaireQuestions, ({ one, many }) => ({
  questionnaire: one(questionnaires, {
    fields: [questionnaireQuestions.questionnaireId],
    references: [questionnaires.id],
  }),
  answers: many(questionnaireAnswers),
}));

// Questionnaire Responses (container for a complete submission)
export const questionnaireResponses = pgTable("questionnaire_responses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  questionnaireId: varchar("questionnaire_id").notNull().references(() => questionnaires.id, { onDelete: 'cascade' }),
  assessmentId: varchar("assessment_id").notNull().references(() => assessments.id, { onDelete: 'cascade' }),
  beneficiaryId: varchar("beneficiary_id").notNull().references(() => users.id, { onDelete: 'cascade' }),
  completed: integer("completed").notNull().default(0),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const questionnaireResponsesRelations = relations(questionnaireResponses, ({ one, many }) => ({
  questionnaire: one(questionnaires, {
    fields: [questionnaireResponses.questionnaireId],
    references: [questionnaires.id],
  }),
  assessment: one(assessments, {
    fields: [questionnaireResponses.assessmentId],
    references: [assessments.id],
  }),
  beneficiary: one(users, {
    fields: [questionnaireResponses.beneficiaryId],
    references: [users.id],
  }),
  answers: many(questionnaireAnswers),
}));

// Questionnaire Answers (individual responses to questions)
export const questionnaireAnswers = pgTable("questionnaire_answers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  responseId: varchar("response_id").notNull().references(() => questionnaireResponses.id, { onDelete: 'cascade' }),
  questionId: varchar("question_id").notNull().references(() => questionnaireQuestions.id, { onDelete: 'cascade' }),
  answerText: text("answer_text"),
  answerData: jsonb("answer_data"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Document Types Enum
export const documentTypeEnum = pgEnum('document_type', ['synthesis', 'action_plan', 'skills_report', 'contract']);

// Generated Documents (Documents de synthèse)
export const documents = pgTable("documents", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  assessmentId: varchar("assessment_id").notNull().references(() => assessments.id, { onDelete: 'cascade' }),
  type: documentTypeEnum("type").notNull(),
  title: varchar("title").notNull(),
  content: jsonb("content"), // Structured content for regeneration
  fileUrl: varchar("file_url"), // URL to PDF file
  generatedBy: varchar("generated_by").notNull().references(() => users.id),
  signedBy: varchar("signed_by").references(() => users.id),
  signedAt: timestamp("signed_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const questionnaireAnswersRelations = relations(questionnaireAnswers, ({ one }) => ({
  response: one(questionnaireResponses, {
    fields: [questionnaireAnswers.responseId],
    references: [questionnaireResponses.id],
  }),
  question: one(questionnaireQuestions, {
    fields: [questionnaireAnswers.questionId],
    references: [questionnaireQuestions.id],
  }),
}));

export const documentsRelations = relations(documents, ({ one }) => ({
  assessment: one(assessments, {
    fields: [documents.assessmentId],
    references: [assessments.id],
  }),
  generatedByUser: one(users, {
    fields: [documents.generatedBy],
    references: [users.id],
  }),
  signedByUser: one(users, {
    fields: [documents.signedBy],
    references: [users.id],
  }),
}));

// Zod schemas for validation
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAssessmentSchema = createInsertSchema(assessments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSessionSchema = createInsertSchema(assessmentSessions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  scheduledDate: z.union([z.date(), z.string().transform((val) => new Date(val))]).nullable().optional(),
});

export const insertSkillSchema = createInsertSchema(skills).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAiAnalysisSchema = createInsertSchema(aiAnalyses).omit({
  id: true,
  createdAt: true,
});

export const insertQuestionnaireSchema = createInsertSchema(questionnaires).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertQuestionnaireQuestionSchema = createInsertSchema(questionnaireQuestions).omit({
  id: true,
  createdAt: true,
});

export const insertQuestionnaireResponseSchema = createInsertSchema(questionnaireResponses).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  completedAt: z.coerce.date().optional().nullable(),
});

export const insertQuestionnaireAnswerSchema = createInsertSchema(questionnaireAnswers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Assessment = typeof assessments.$inferSelect;
export type InsertAssessment = z.infer<typeof insertAssessmentSchema>;

export type AssessmentSession = typeof assessmentSessions.$inferSelect;
export type InsertSession = z.infer<typeof insertSessionSchema>;

export type Skill = typeof skills.$inferSelect;
export type InsertSkill = z.infer<typeof insertSkillSchema>;

export type AiAnalysis = typeof aiAnalyses.$inferSelect;
export type InsertAiAnalysis = z.infer<typeof insertAiAnalysisSchema>;

export type Questionnaire = typeof questionnaires.$inferSelect;
export type InsertQuestionnaire = z.infer<typeof insertQuestionnaireSchema>;

export type QuestionnaireQuestion = typeof questionnaireQuestions.$inferSelect;
export type InsertQuestionnaireQuestion = z.infer<typeof insertQuestionnaireQuestionSchema>;

export type QuestionnaireResponse = typeof questionnaireResponses.$inferSelect;
export type InsertQuestionnaireResponse = z.infer<typeof insertQuestionnaireResponseSchema>;

export type QuestionnaireAnswer = typeof questionnaireAnswers.$inferSelect;
export type InsertQuestionnaireAnswer = z.infer<typeof insertQuestionnaireAnswerSchema>;

// Document schemas
export const insertDocumentSchema = createInsertSchema(documents).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type Document = typeof documents.$inferSelect;
export type InsertDocument = z.infer<typeof insertDocumentSchema>;

// Extended types with relations
export type AssessmentWithRelations = Assessment & {
  beneficiary?: User;
  consultant?: User | null;
  sessions?: AssessmentSession[];
  skills?: Skill[];
  aiAnalyses?: AiAnalysis[];
};

export type QuestionnaireWithQuestions = Questionnaire & {
  questions?: QuestionnaireQuestion[];
};

export type QuestionnaireResponseWithAnswers = QuestionnaireResponse & {
  answers?: QuestionnaireAnswer[];
  questionnaire?: Questionnaire;
};
