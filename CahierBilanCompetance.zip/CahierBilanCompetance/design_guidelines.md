# Design Guidelines: BilanCompetence.AI

## Design Approach

**Selected Approach**: Design System-Inspired with Modern SaaS Aesthetics

Drawing from **Linear's precision**, **Notion's clarity**, and **professional French business platforms**, this design prioritizes:
- Clean, scannable interfaces for data-heavy content
- Professional trust signals for career assessment context
- Efficient workflows for consultant productivity
- Welcoming, reassuring experience for beneficiaries

## Typography

**Font Families** (via Google Fonts):
- Primary: 'Inter' - Clean, professional, excellent readability for French accents
- Headings: 'Inter' (600-700 weight)
- Body: 'Inter' (400-500 weight)
- Data/Numbers: 'Inter' (500-600 weight)

**Type Scale**:
- Hero/Page Titles: text-4xl lg:text-5xl (font-semibold)
- Section Headers: text-2xl lg:text-3xl (font-semibold)
- Card Titles: text-lg (font-medium)
- Body Text: text-base (font-normal)
- Metadata/Labels: text-sm (font-medium)
- Small Print: text-xs

## Layout System

**Spacing Primitives**: Use Tailwind units of **2, 4, 6, 8, 12, 16, 20, 24**
- Micro spacing (between related items): gap-2, gap-4
- Component padding: p-6, p-8
- Section spacing: py-12, py-16, py-20
- Page margins: px-4 md:px-8 lg:px-12

**Grid System**:
- Dashboards: 12-column grid with gap-6
- Forms: Single column max-w-2xl for optimal reading
- Card grids: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 with gap-6

**Container Widths**:
- Marketing pages: max-w-7xl
- Application dashboards: max-w-screen-2xl
- Forms/Content: max-w-3xl

## Component Library

### Navigation
**Main App Navigation**:
- Persistent sidebar (280px width) with role-specific menu items
- Top bar with user profile, notifications, organization switcher
- Breadcrumbs for deep navigation contexts

**Marketing Site Navigation**:
- Horizontal navigation with sticky behavior
- Clear CTA buttons ("Essai Gratuit", "Connexion")

### Cards & Containers
**Standard Cards**:
- Rounded corners: rounded-lg
- Subtle borders: border border-gray-200
- Padding: p-6
- Hover states: hover:shadow-md transition-shadow

**Assessment Cards** (for beneficiaries):
- Progress indicators with percentage
- Status badges (En cours, Terminé, À venir)
- Clear CTAs for next actions

**Consultant Client Cards**:
- Avatar + name + current phase
- Quick action buttons
- Last interaction timestamp

### Forms & Inputs
**Input Fields**:
- Full-width in forms
- Clear labels above inputs (text-sm font-medium)
- Helper text below (text-xs text-gray-600)
- Focus states with subtle border emphasis
- Consistent height: h-11

**Multi-step Forms**:
- Progress stepper at top showing phases
- "Précédent" / "Suivant" navigation
- Save draft functionality visible

**Skills Assessment Interface**:
- Slider inputs for proficiency levels (Débutant → Expert)
- Toggle buttons for preference (J'aime, Neutre, N'aime pas)
- Tag-based selection for contexts

### Data Display
**Tables**:
- Striped rows for scanability
- Sortable columns with icons
- Pagination at bottom
- Actions column (always right-aligned)

**Stats/Metrics**:
- Large number displays (text-3xl font-bold)
- Small label underneath (text-sm text-gray-600)
- Icon accompaniment for context
- Trend indicators where relevant

**Progress Tracking**:
- Linear progress bars for phase completion
- Step indicators (1→2→3) with visual connection
- Time estimates for each phase

### Buttons & Actions
**Primary Actions**: Solid background, medium padding (px-6 py-3), font-medium
**Secondary Actions**: Bordered, same padding
**Tertiary Actions**: Text-only with hover underline
**Icon Buttons**: Square (h-10 w-10), centered icon

### Document Generation
**Synthesis Report Preview**:
- Professional document layout with header/footer
- Section dividers
- Export buttons (PDF, Print)
- Shareable link generation

### Dashboards
**Admin Dashboard**:
- KPI cards at top (4-column grid)
- Charts for trends (line charts, bar charts via Chart.js)
- Recent activity feed
- Quick filters and date range selectors

**Consultant Dashboard**:
- Today's appointments prominent
- Active assessments grid
- Quick actions panel

**Beneficiary Dashboard**:
- Current assessment progress hero
- Timeline of phases
- Resources and next steps

## Images

**Marketing/Landing Pages**:
- **Hero Section**: Large professional image (1920x800px) showing consultant-client interaction or professional setting, with overlay text and blurred-background CTA buttons
- **Features Section**: Icon-based (no photos needed)
- **Testimonials**: Small circular avatars (80x80px) for consultant/beneficiary testimonials
- **About/Team**: Professional headshots in consistent style

**Application**:
- User avatars throughout (32x32, 40x40, 64x64 variants)
- Empty states with friendly illustrations
- Consultant profile photos

## Animations

**Minimal Use**:
- Page transitions: Simple fade-in (200ms)
- Card hover: Subtle shadow lift
- Form validation: Shake on error
- Success states: Checkmark fade-in
- NO scroll-triggered animations
- NO complex hero animations

## French Language Considerations

- Ensure adequate spacing for longer French words
- Use proper typographic conventions (guillemets « », spaces before punctuation)
- Professional "vous" form throughout
- Clear, concise professional language

## Accessibility & Quality

- Minimum touch targets: 44x44px
- Keyboard navigation for all interactive elements
- Clear focus indicators (2px ring)
- WCAG AA contrast ratios minimum
- Screen reader labels on icons
- Proper heading hierarchy

## Role-Specific Visual Cues

**Beneficiary Views**: Warm, reassuring, guided
**Consultant Views**: Efficient, data-dense, professional
**Admin Views**: Analytical, comprehensive, control-focused

Use subtle visual differentiation (accent indicators, layout density) rather than heavy theming.