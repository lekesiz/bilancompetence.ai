// Referenced from javascript_database and javascript_log_in_with_replit blueprints
import {
  users,
  assessments,
  assessmentSessions,
  skills,
  aiAnalyses,
  questionnaires,
  questionnaireQuestions,
  questionnaireResponses,
  questionnaireAnswers,
  type User,
  type UpsertUser,
  type Assessment,
  type InsertAssessment,
  type AssessmentSession,
  type InsertSession,
  type Skill,
  type InsertSkill,
  type AiAnalysis,
  type InsertAiAnalysis,
  type Questionnaire,
  type InsertQuestionnaire,
  type QuestionnaireQuestion,
  type InsertQuestionnaireQuestion,
  type QuestionnaireResponse,
  type InsertQuestionnaireResponse,
  type QuestionnaireAnswer,
  type InsertQuestionnaireAnswer,
  type AssessmentWithRelations,
  type QuestionnaireWithQuestions,
  type QuestionnaireResponseWithAnswers,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";

export interface IStorage {
  // User operations (required for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  getUserByRole(role: string): Promise<User[]>;
  
  // Assessment operations
  getAssessment(id: string): Promise<AssessmentWithRelations | undefined>;
  getAssessmentsByBeneficiary(beneficiaryId: string): Promise<AssessmentWithRelations[]>;
  getAssessmentsByConsultant(consultantId: string): Promise<AssessmentWithRelations[]>;
  getAllAssessments(): Promise<AssessmentWithRelations[]>;
  createAssessment(assessment: InsertAssessment): Promise<Assessment>;
  updateAssessment(id: string, data: Partial<InsertAssessment>): Promise<Assessment | undefined>;
  deleteAssessment(id: string): Promise<void>;
  
  // Session operations
  getSession(id: string): Promise<AssessmentSession | undefined>;
  getSessionsByAssessment(assessmentId: string): Promise<AssessmentSession[]>;
  createSession(session: InsertSession): Promise<AssessmentSession>;
  updateSession(id: string, data: Partial<InsertSession>): Promise<AssessmentSession | undefined>;
  deleteSession(id: string): Promise<void>;
  
  // Skill operations
  getSkill(id: string): Promise<Skill | undefined>;
  getSkillsByAssessment(assessmentId: string): Promise<Skill[]>;
  createSkill(skill: InsertSkill): Promise<Skill>;
  updateSkill(id: string, data: Partial<InsertSkill>): Promise<Skill | undefined>;
  deleteSkill(id: string): Promise<void>;
  
  // AI Analysis operations
  getAiAnalysis(id: string): Promise<AiAnalysis | undefined>;
  getAiAnalysesByAssessment(assessmentId: string): Promise<AiAnalysis[]>;
  createAiAnalysis(analysis: InsertAiAnalysis): Promise<AiAnalysis>;
  
  // Questionnaire operations
  getQuestionnaire(id: string): Promise<QuestionnaireWithQuestions | undefined>;
  getQuestionnairesByPhase(phase: string): Promise<QuestionnaireWithQuestions[]>;
  getAllActiveQuestionnaires(): Promise<QuestionnaireWithQuestions[]>;
  createQuestionnaire(questionnaire: InsertQuestionnaire): Promise<Questionnaire>;
  
  // Questionnaire Question operations
  createQuestion(question: InsertQuestionnaireQuestion): Promise<QuestionnaireQuestion>;
  
  // Questionnaire Response operations
  getResponse(id: string): Promise<QuestionnaireResponseWithAnswers | undefined>;
  getResponsesByAssessment(assessmentId: string): Promise<QuestionnaireResponseWithAnswers[]>;
  createResponse(response: InsertQuestionnaireResponse): Promise<QuestionnaireResponse>;
  updateResponse(id: string, data: Partial<InsertQuestionnaireResponse>): Promise<QuestionnaireResponse | undefined>;
  
  // Questionnaire Answer operations
  getAnswer(id: string): Promise<QuestionnaireAnswer | undefined>;
  createAnswer(answer: InsertQuestionnaireAnswer): Promise<QuestionnaireAnswer>;
  updateAnswer(id: string, data: Partial<InsertQuestionnaireAnswer>): Promise<QuestionnaireAnswer | undefined>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  async getUserByRole(role: string): Promise<User[]> {
    return await db.select().from(users).where(eq(users.role, role as any));
  }

  // Assessment operations
  async getAssessment(id: string): Promise<AssessmentWithRelations | undefined> {
    const [assessment] = await db
      .select()
      .from(assessments)
      .where(eq(assessments.id, id));
    
    if (!assessment) return undefined;

    const [beneficiary] = await db.select().from(users).where(eq(users.id, assessment.beneficiaryId));
    const consultant = assessment.consultantId 
      ? (await db.select().from(users).where(eq(users.id, assessment.consultantId)))[0]
      : null;
    const sessions = await db.select().from(assessmentSessions).where(eq(assessmentSessions.assessmentId, id));
    const assessmentSkills = await db.select().from(skills).where(eq(skills.assessmentId, id));
    const analyses = await db.select().from(aiAnalyses).where(eq(aiAnalyses.assessmentId, id));

    return {
      ...assessment,
      beneficiary,
      consultant,
      sessions,
      skills: assessmentSkills,
      aiAnalyses: analyses,
    };
  }

  async getAssessmentsByBeneficiary(beneficiaryId: string): Promise<AssessmentWithRelations[]> {
    const allAssessments = await db
      .select()
      .from(assessments)
      .where(eq(assessments.beneficiaryId, beneficiaryId))
      .orderBy(desc(assessments.createdAt));

    return await Promise.all(
      allAssessments.map(async (assessment) => {
        const [beneficiary] = await db.select().from(users).where(eq(users.id, assessment.beneficiaryId));
        const consultant = assessment.consultantId 
          ? (await db.select().from(users).where(eq(users.id, assessment.consultantId)))[0]
          : null;
        const sessions = await db.select().from(assessmentSessions).where(eq(assessmentSessions.assessmentId, assessment.id));
        const assessmentSkills = await db.select().from(skills).where(eq(skills.assessmentId, assessment.id));
        const analyses = await db.select().from(aiAnalyses).where(eq(aiAnalyses.assessmentId, assessment.id));

        return {
          ...assessment,
          beneficiary,
          consultant,
          sessions,
          skills: assessmentSkills,
          aiAnalyses: analyses,
        };
      })
    );
  }

  async getAssessmentsByConsultant(consultantId: string): Promise<AssessmentWithRelations[]> {
    const allAssessments = await db
      .select()
      .from(assessments)
      .where(eq(assessments.consultantId, consultantId))
      .orderBy(desc(assessments.createdAt));

    return await Promise.all(
      allAssessments.map(async (assessment) => {
        const [beneficiary] = await db.select().from(users).where(eq(users.id, assessment.beneficiaryId));
        const consultant = assessment.consultantId 
          ? (await db.select().from(users).where(eq(users.id, assessment.consultantId)))[0]
          : null;
        const sessions = await db.select().from(assessmentSessions).where(eq(assessmentSessions.assessmentId, assessment.id));
        const assessmentSkills = await db.select().from(skills).where(eq(skills.assessmentId, assessment.id));
        const analyses = await db.select().from(aiAnalyses).where(eq(aiAnalyses.assessmentId, assessment.id));

        return {
          ...assessment,
          beneficiary,
          consultant,
          sessions,
          skills: assessmentSkills,
          aiAnalyses: analyses,
        };
      })
    );
  }

  async getAllAssessments(): Promise<AssessmentWithRelations[]> {
    const allAssessments = await db.select().from(assessments).orderBy(desc(assessments.createdAt));

    return await Promise.all(
      allAssessments.map(async (assessment) => {
        const [beneficiary] = await db.select().from(users).where(eq(users.id, assessment.beneficiaryId));
        const consultant = assessment.consultantId 
          ? (await db.select().from(users).where(eq(users.id, assessment.consultantId)))[0]
          : null;
        const sessions = await db.select().from(assessmentSessions).where(eq(assessmentSessions.assessmentId, assessment.id));
        const assessmentSkills = await db.select().from(skills).where(eq(skills.assessmentId, assessment.id));
        const analyses = await db.select().from(aiAnalyses).where(eq(aiAnalyses.assessmentId, assessment.id));

        return {
          ...assessment,
          beneficiary,
          consultant,
          sessions,
          skills: assessmentSkills,
          aiAnalyses: analyses,
        };
      })
    );
  }

  async createAssessment(assessmentData: InsertAssessment): Promise<Assessment> {
    const [assessment] = await db.insert(assessments).values(assessmentData).returning();
    return assessment;
  }

  async updateAssessment(id: string, data: Partial<InsertAssessment>): Promise<Assessment | undefined> {
    const [assessment] = await db
      .update(assessments)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(assessments.id, id))
      .returning();
    return assessment;
  }

  async deleteAssessment(id: string): Promise<void> {
    await db.delete(assessments).where(eq(assessments.id, id));
  }

  // Session operations
  async getSession(id: string): Promise<AssessmentSession | undefined> {
    const [session] = await db.select().from(assessmentSessions).where(eq(assessmentSessions.id, id));
    return session;
  }

  async getSessionsByAssessment(assessmentId: string): Promise<AssessmentSession[]> {
    return await db.select().from(assessmentSessions).where(eq(assessmentSessions.assessmentId, assessmentId));
  }

  async createSession(sessionData: InsertSession): Promise<AssessmentSession> {
    const [session] = await db.insert(assessmentSessions).values(sessionData).returning();
    return session;
  }

  async updateSession(id: string, data: Partial<InsertSession>): Promise<AssessmentSession | undefined> {
    const [session] = await db
      .update(assessmentSessions)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(assessmentSessions.id, id))
      .returning();
    return session;
  }

  async deleteSession(id: string): Promise<void> {
    await db.delete(assessmentSessions).where(eq(assessmentSessions.id, id));
  }

  // Skill operations
  async getSkill(id: string): Promise<Skill | undefined> {
    const [skill] = await db.select().from(skills).where(eq(skills.id, id));
    return skill;
  }

  async getSkillsByAssessment(assessmentId: string): Promise<Skill[]> {
    return await db.select().from(skills).where(eq(skills.assessmentId, assessmentId));
  }

  async createSkill(skillData: InsertSkill): Promise<Skill> {
    const [skill] = await db.insert(skills).values(skillData).returning();
    return skill;
  }

  async updateSkill(id: string, data: Partial<InsertSkill>): Promise<Skill | undefined> {
    const [skill] = await db
      .update(skills)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(skills.id, id))
      .returning();
    return skill;
  }

  async deleteSkill(id: string): Promise<void> {
    await db.delete(skills).where(eq(skills.id, id));
  }

  // AI Analysis operations
  async getAiAnalysis(id: string): Promise<AiAnalysis | undefined> {
    const [analysis] = await db.select().from(aiAnalyses).where(eq(aiAnalyses.id, id));
    return analysis;
  }

  async getAiAnalysesByAssessment(assessmentId: string): Promise<AiAnalysis[]> {
    return await db.select().from(aiAnalyses).where(eq(aiAnalyses.assessmentId, assessmentId));
  }

  async createAiAnalysis(analysisData: InsertAiAnalysis): Promise<AiAnalysis> {
    const [analysis] = await db.insert(aiAnalyses).values(analysisData).returning();
    return analysis;
  }

  // Questionnaire operations
  async getQuestionnaire(id: string): Promise<QuestionnaireWithQuestions | undefined> {
    const [questionnaire] = await db.select().from(questionnaires).where(eq(questionnaires.id, id));
    if (!questionnaire) return undefined;

    const questions = await db
      .select()
      .from(questionnaireQuestions)
      .where(eq(questionnaireQuestions.questionnaireId, id))
      .orderBy(questionnaireQuestions.order);

    return {
      ...questionnaire,
      questions,
    };
  }

  async getQuestionnairesByPhase(phase: string): Promise<QuestionnaireWithQuestions[]> {
    const allQuestionnaires = await db
      .select()
      .from(questionnaires)
      .where(and(eq(questionnaires.phase, phase as any), eq(questionnaires.isActive, 1)))
      .orderBy(questionnaires.order);

    return await Promise.all(
      allQuestionnaires.map(async (questionnaire) => {
        const questions = await db
          .select()
          .from(questionnaireQuestions)
          .where(eq(questionnaireQuestions.questionnaireId, questionnaire.id))
          .orderBy(questionnaireQuestions.order);

        return {
          ...questionnaire,
          questions,
        };
      })
    );
  }

  async getAllActiveQuestionnaires(): Promise<QuestionnaireWithQuestions[]> {
    const allQuestionnaires = await db
      .select()
      .from(questionnaires)
      .where(eq(questionnaires.isActive, 1))
      .orderBy(questionnaires.phase, questionnaires.order);

    return await Promise.all(
      allQuestionnaires.map(async (questionnaire) => {
        const questions = await db
          .select()
          .from(questionnaireQuestions)
          .where(eq(questionnaireQuestions.questionnaireId, questionnaire.id))
          .orderBy(questionnaireQuestions.order);

        return {
          ...questionnaire,
          questions,
        };
      })
    );
  }

  async createQuestionnaire(questionnaireData: InsertQuestionnaire): Promise<Questionnaire> {
    const [questionnaire] = await db.insert(questionnaires).values(questionnaireData).returning();
    return questionnaire;
  }

  // Questionnaire Question operations
  async createQuestion(questionData: InsertQuestionnaireQuestion): Promise<QuestionnaireQuestion> {
    const [question] = await db.insert(questionnaireQuestions).values(questionData).returning();
    return question;
  }

  // Questionnaire Response operations
  async getResponse(id: string): Promise<QuestionnaireResponseWithAnswers | undefined> {
    const [response] = await db.select().from(questionnaireResponses).where(eq(questionnaireResponses.id, id));
    if (!response) return undefined;

    const [questionnaire] = await db.select().from(questionnaires).where(eq(questionnaires.id, response.questionnaireId));
    const answers = await db
      .select()
      .from(questionnaireAnswers)
      .where(eq(questionnaireAnswers.responseId, id));

    return {
      ...response,
      questionnaire,
      answers,
    };
  }

  async getResponsesByAssessment(assessmentId: string): Promise<QuestionnaireResponseWithAnswers[]> {
    const allResponses = await db
      .select()
      .from(questionnaireResponses)
      .where(eq(questionnaireResponses.assessmentId, assessmentId));

    return await Promise.all(
      allResponses.map(async (response) => {
        const [questionnaire] = await db.select().from(questionnaires).where(eq(questionnaires.id, response.questionnaireId));
        const answers = await db
          .select()
          .from(questionnaireAnswers)
          .where(eq(questionnaireAnswers.responseId, response.id));

        return {
          ...response,
          questionnaire,
          answers,
        };
      })
    );
  }

  async createResponse(responseData: InsertQuestionnaireResponse): Promise<QuestionnaireResponse> {
    const [response] = await db.insert(questionnaireResponses).values(responseData).returning();
    return response;
  }

  async updateResponse(id: string, data: Partial<InsertQuestionnaireResponse>): Promise<QuestionnaireResponse | undefined> {
    const [response] = await db
      .update(questionnaireResponses)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(questionnaireResponses.id, id))
      .returning();
    return response;
  }

  // Questionnaire Answer operations
  async getAnswer(id: string): Promise<QuestionnaireAnswer | undefined> {
    const [answer] = await db.select().from(questionnaireAnswers).where(eq(questionnaireAnswers.id, id));
    return answer;
  }

  async createAnswer(answerData: InsertQuestionnaireAnswer): Promise<QuestionnaireAnswer> {
    const [answer] = await db.insert(questionnaireAnswers).values(answerData).returning();
    return answer;
  }

  async updateAnswer(id: string, data: Partial<InsertQuestionnaireAnswer>): Promise<QuestionnaireAnswer | undefined> {
    const [answer] = await db
      .update(questionnaireAnswers)
      .set({ ...data, updatedAt: new Date() })
      .where(eq(questionnaireAnswers.id, id))
      .returning();
    return answer;
  }
}

export const storage = new DatabaseStorage();
