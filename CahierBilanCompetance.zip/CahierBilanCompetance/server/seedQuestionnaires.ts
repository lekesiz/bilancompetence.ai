import { db } from "./db";
import { questionnaires, questionnaireQuestions } from "@shared/schema";

async function seedQuestionnaires() {
  console.log("🌱 Seeding questionnaires...");

  // Create preliminary phase questionnaire
  const [preliminaryQuestionnaire] = await db
    .insert(questionnaires)
    .values({
      title: "Auto-évaluation préliminaire",
      description: "Ce questionnaire vous permet de clarifier vos motivations et objectifs pour ce bilan de compétences.",
      phase: "preliminary",
      order: 1,
      isActive: 1,
    })
    .returning();

  console.log(`✅ Created questionnaire: ${preliminaryQuestionnaire.title}`);

  // Add questions to the questionnaire
  const questions = [
    {
      questionnaireId: preliminaryQuestionnaire.id,
      questionText: "Quelles sont vos principales motivations pour réaliser ce bilan de compétences ?",
      questionType: "textarea" as const,
      required: 1,
      order: 1,
    },
    {
      questionnaireId: preliminaryQuestionnaire.id,
      questionText: "Quelle est votre situation professionnelle actuelle ?",
      questionType: "radio" as const,
      options: ["En poste", "En recherche d'emploi", "En reconversion", "En formation", "Autre"],
      required: 1,
      order: 2,
    },
    {
      questionnaireId: preliminaryQuestionnaire.id,
      questionText: "Depuis combien d'années êtes-vous dans votre poste actuel ou dans votre domaine professionnel ?",
      questionType: "text" as const,
      required: 1,
      order: 3,
    },
    {
      questionnaireId: preliminaryQuestionnaire.id,
      questionText: "Quels sont vos objectifs principaux pour ce bilan de compétences ? (plusieurs choix possibles)",
      questionType: "checkbox" as const,
      options: [
        "Identifier mes compétences transférables",
        "Explorer de nouvelles pistes professionnelles",
        "Préparer une reconversion",
        "Évoluer dans mon entreprise actuelle",
        "Valider un projet professionnel",
        "Développer de nouvelles compétences",
      ],
      required: 1,
      order: 4,
    },
    {
      questionnaireId: preliminaryQuestionnaire.id,
      questionText: "Avez-vous déjà identifié un projet professionnel précis ?",
      questionType: "radio" as const,
      options: ["Oui, j'ai un projet clair", "J'ai quelques pistes", "Non, je cherche encore", "Je ne sais pas"],
      required: 1,
      order: 5,
    },
    {
      questionnaireId: preliminaryQuestionnaire.id,
      questionText: "Si oui, décrivez brièvement votre projet professionnel :",
      questionType: "textarea" as const,
      required: 0,
      order: 6,
    },
    {
      questionnaireId: preliminaryQuestionnaire.id,
      questionText: "Quelles sont vos principales forces professionnelles selon vous ?",
      questionType: "textarea" as const,
      required: 1,
      order: 7,
    },
    {
      questionnaireId: preliminaryQuestionnaire.id,
      questionText: "Quels aspects de votre vie professionnelle souhaitez-vous améliorer ?",
      questionType: "textarea" as const,
      required: 1,
      order: 8,
    },
    {
      questionnaireId: preliminaryQuestionnaire.id,
      questionText: "Sur une échelle de 1 à 5, à quel point êtes-vous prêt(e) à envisager un changement professionnel ?",
      questionType: "scale" as const,
      options: ["1", "2", "3", "4", "5"],
      required: 1,
      order: 9,
    },
    {
      questionnaireId: preliminaryQuestionnaire.id,
      questionText: "Avez-vous des contraintes particulières à prendre en compte (géographiques, familiales, financières, etc.) ?",
      questionType: "textarea" as const,
      required: 0,
      order: 10,
    },
  ];

  for (const question of questions) {
    await db.insert(questionnaireQuestions).values(question);
  }

  console.log(`✅ Added ${questions.length} questions to questionnaire`);
  console.log("✅ Questionnaire seeding complete!");
}

seedQuestionnaires()
  .then(() => {
    console.log("🎉 All done!");
    process.exit(0);
  })
  .catch((error) => {
    console.error("❌ Error seeding questionnaires:", error);
    process.exit(1);
  });
