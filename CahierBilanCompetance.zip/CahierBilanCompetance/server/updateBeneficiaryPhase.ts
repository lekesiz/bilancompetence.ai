import { db } from "./db";
import { assessments } from "@shared/schema";
import { eq } from "drizzle-orm";

async function updatePhase() {
  console.log("🔄 Updating beneficiary assessment phase...");

  await db
    .update(assessments)
    .set({ currentPhase: "preliminary", progressPercentage: 10 })
    .where(eq(assessments.beneficiaryId, "beneficiary-test-001"));

  console.log("✅ Updated beneficiary assessment to preliminary phase");
}

updatePhase()
  .then(() => {
    console.log("🎉 Done!");
    process.exit(0);
  })
  .catch((error) => {
    console.error("❌ Error:", error);
    process.exit(1);
  });
