// Referenced from javascript_openai_ai_integrations blueprint
import OpenAI from "openai";
import type { Skill } from "@shared/schema";

// This is using Replit's AI Integrations service, which provides OpenAI-compatible API access without requiring your own OpenAI API key.
const openai = new OpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY
});

export interface SkillsAnalysisResult {
  transferableSkills: string[];
  careerRecommendations: string[];
  strengthsAnalysis: string;
  developmentAreas: string;
}

export async function analyzeSkills(skills: Skill[], userObjectives?: string): Promise<SkillsAnalysisResult> {
  const skillsDescription = skills.map(s => 
    `${s.name} (Niveau: ${s.level}, Préférence: ${s.preference || 'neutral'}, Contexte: ${s.context || 'non spécifié'})`
  ).join('\n');

  const prompt = `En tant qu'expert en bilan de compétences, analyse les compétences suivantes d'un bénéficiaire :

COMPÉTENCES :
${skillsDescription}

${userObjectives ? `OBJECTIFS DU BÉNÉFICIAIRE : ${userObjectives}` : ''}

Fournis une analyse en JSON avec les clés suivantes :
- transferableSkills : tableau de compétences transférables vers d'autres métiers
- careerRecommendations : tableau de 5-7 pistes de métiers/secteurs correspondant au profil
- strengthsAnalysis : analyse textuelle des points forts (2-3 phrases)
- developmentAreas : analyse textuelle des axes de développement (2-3 phrases)

Réponds UNIQUEMENT en JSON valide, en français professionnel.`;

  try {
    // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
    const response = await openai.chat.completions.create({
      model: "gpt-5",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      max_completion_tokens: 8192,
    });

    const content = response.choices[0]?.message?.content || '{}';
    const result = JSON.parse(content) as SkillsAnalysisResult;
    
    return result;
  } catch (error) {
    console.error("AI Analysis error:", error);
    // Return fallback analysis
    return {
      transferableSkills: skills.filter(s => s.level === 'advanced' || s.level === 'expert').map(s => s.name),
      careerRecommendations: [
        "Analyse en cours - Consultez votre consultant pour des recommandations personnalisées"
      ],
      strengthsAnalysis: "L'analyse détaillée sera disponible prochainement.",
      developmentAreas: "L'analyse détaillée sera disponible prochainement.",
    };
  }
}

export interface CareerPathRecommendation {
  jobTitle: string;
  matchScore: number;
  requiredSkills: string[];
  missingSkills: string[];
  description: string;
}

export async function generateCareerPaths(skills: Skill[], objectives?: string): Promise<CareerPathRecommendation[]> {
  const skillsList = skills.map(s => s.name).join(', ');

  const prompt = `En tant qu'expert en orientation professionnelle, propose 5 pistes de carrière pour une personne possédant les compétences suivantes :

COMPÉTENCES : ${skillsList}

${objectives ? `OBJECTIFS : ${objectives}` : ''}

Fournis un tableau JSON avec pour chaque piste :
- jobTitle : intitulé du métier
- matchScore : score de correspondance (0-100)
- requiredSkills : tableau des compétences requises
- missingSkills : tableau des compétences à développer
- description : description courte du métier (1-2 phrases)

Réponds UNIQUEMENT en JSON valide avec un tableau de 5 objets.`;

  try {
    const response = await openai.chat.completions.create({
      model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
      max_completion_tokens: 8192,
    });

    const content = response.choices[0]?.message?.content || '{"paths": []}';
    const result = JSON.parse(content);
    
    return result.paths || result.recommendations || [];
  } catch (error) {
    console.error("Career paths generation error:", error);
    return [];
  }
}
