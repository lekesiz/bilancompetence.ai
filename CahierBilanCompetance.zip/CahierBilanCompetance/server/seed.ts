import { db } from "./db";
import { users, assessments, skills } from "@shared/schema";

async function seed() {
  console.log("Seeding database...");

  // Create test users with different roles
  const testUsers = [
    {
      id: "admin-test-001",
      email: "admin@bilancompetence.ai",
      firstName: "Admin",
      lastName: "Test",
      role: "admin" as const,
    },
    {
      id: "consultant-test-001",
      email: "consultant@bilancompetence.ai",
      firstName: "Marie",
      lastName: "Dupont",
      role: "consultant" as const,
      bio: "Consultante en bilan de compétences avec 10 ans d'expérience",
    },
    {
      id: "beneficiary-test-001",
      email: "beneficiary@bilancompetence.ai",
      firstName: "Jean",
      lastName: "Martin",
      role: "beneficiary" as const,
    },
  ];

  for (const userData of testUsers) {
    await db
      .insert(users)
      .values(userData)
      .onConflictDoNothing();
  }

  console.log("✓ Created test users");

  // Create a sample assessment for the test beneficiary
  const [assessment] = await db
    .insert(assessments)
    .values({
      beneficiaryId: "beneficiary-test-001",
      consultantId: "consultant-test-001",
      currentPhase: "investigation",
      status: "in_progress",
      objectives: "Explorer des opportunités de reconversion dans le secteur du numérique",
      startDate: new Date(),
      progressPercentage: 35,
    })
    .onConflictDoNothing()
    .returning();

  if (assessment) {
    console.log("✓ Created sample assessment");

    // Add sample skills
    const sampleSkills = [
      {
        assessmentId: assessment.id,
        name: "Gestion de projet",
        category: "Organisationnel",
        level: "advanced" as const,
        preference: "love" as const,
        context: "Expérience professionnelle",
        yearsOfExperience: 5,
      },
      {
        assessmentId: assessment.id,
        name: "Communication",
        category: "Relationnel",
        level: "expert" as const,
        preference: "love" as const,
        context: "Formation et expérience",
        yearsOfExperience: 8,
      },
      {
        assessmentId: assessment.id,
        name: "Analyse de données",
        category: "Technique",
        level: "intermediate" as const,
        preference: "neutral" as const,
        context: "Formation",
        yearsOfExperience: 2,
      },
    ];

    await db.insert(skills).values(sampleSkills);
    console.log("✓ Created sample skills");
  }

  console.log("Database seeded successfully!");
}

seed()
  .catch((error) => {
    console.error("Seed error:", error);
    process.exit(1);
  })
  .then(() => process.exit(0));
