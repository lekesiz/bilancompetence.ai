// Referenced from javascript_log_in_with_replit blueprint
import type { Express } from "express";
import { createServer, type Server } from "http";
import { z } from "zod";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { analyzeSkills, generateCareerPaths } from "./aiService";
import { insertAssessmentSchema, insertSessionSchema, insertSkillSchema, insertAiAnalysisSchema, insertQuestionnaireSchema, insertQuestionnaireQuestionSchema, insertQuestionnaireResponseSchema, insertQuestionnaireAnswerSchema } from "@shared/schema";
import { fromError } from "zod-validation-error";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Update user role (admin only)
  app.patch('/api/users/:id/role', isAuthenticated, async (req: any, res) => {
    try {
      const currentUserId = req.user.claims.sub;
      const currentUser = await storage.getUser(currentUserId);
      
      if (currentUser?.role !== 'admin') {
        return res.status(403).json({ message: "Forbidden - Admin only" });
      }

      // Validate request body with Zod
      const roleUpdateSchema = z.object({
        role: z.enum(['beneficiary', 'consultant', 'admin']),
      });

      const validated = roleUpdateSchema.parse(req.body);

      // Prevent self-demotion (admin changing their own role)
      if (req.params.id === currentUserId) {
        return res.status(400).json({ message: "Cannot modify your own role" });
      }

      const targetUser = await storage.getUser(req.params.id);
      if (!targetUser) {
        return res.status(404).json({ message: "User not found" });
      }

      // Prevent redundant writes
      if (targetUser.role === validated.role) {
        return res.json(targetUser);
      }

      const updated = await storage.upsertUser({
        ...targetUser,
        role: validated.role,
      });

      console.log(`[Audit] Admin ${currentUserId} changed user ${req.params.id} role from ${targetUser.role} to ${validated.role}`);
      
      res.json(updated);
    } catch (error: any) {
      console.error("Error updating user role:", error);
      if (error.name === 'ZodError') {
        const validationError = fromError(error);
        return res.status(400).json({ message: validationError.toString() });
      }
      res.status(500).json({ message: "Failed to update role" });
    }
  });

  // Assessment routes
  app.get('/api/assessments/my-assessment', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const assessments = await storage.getAssessmentsByBeneficiary(userId);
      // Return the most recent active assessment
      const activeAssessment = assessments.find(a => a.status !== 'completed' && a.status !== 'cancelled');
      res.json(activeAssessment || assessments[0] || null);
    } catch (error) {
      console.error("Error fetching assessment:", error);
      res.status(500).json({ message: "Failed to fetch assessment" });
    }
  });

  app.get('/api/assessments/:id', isAuthenticated, async (req: any, res) => {
    try {
      const assessment = await storage.getAssessment(req.params.id);
      if (!assessment) {
        return res.status(404).json({ message: "Assessment not found" });
      }
      res.json(assessment);
    } catch (error) {
      console.error("Error fetching assessment:", error);
      res.status(500).json({ message: "Failed to fetch assessment" });
    }
  });

  app.post('/api/assessments', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const validated = insertAssessmentSchema.parse({ ...req.body, beneficiaryId: userId });
      const assessment = await storage.createAssessment(validated);
      res.status(201).json(assessment);
    } catch (error: any) {
      console.error("Error creating assessment:", error);
      const validationError = fromError(error);
      res.status(400).json({ message: validationError.toString() });
    }
  });

  app.patch('/api/assessments/:id', isAuthenticated, async (req: any, res) => {
    try {
      const assessment = await storage.updateAssessment(req.params.id, req.body);
      if (!assessment) {
        return res.status(404).json({ message: "Assessment not found" });
      }
      res.json(assessment);
    } catch (error) {
      console.error("Error updating assessment:", error);
      res.status(500).json({ message: "Failed to update assessment" });
    }
  });

  app.delete('/api/assessments/:id', isAuthenticated, async (req: any, res) => {
    try {
      await storage.deleteAssessment(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting assessment:", error);
      res.status(500).json({ message: "Failed to delete assessment" });
    }
  });

  // Session routes
  app.get('/api/sessions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      // Beneficiaries get sessions from their assessments
      if (user?.role === 'beneficiary') {
        const assessments = await storage.getAssessmentsByBeneficiary(userId);
        const allSessions = [];
        for (const assessment of assessments) {
          const sessions = await storage.getSessionsByAssessment(assessment.id);
          allSessions.push(...sessions);
        }
        return res.json(allSessions);
      }
      
      // Consultants get all their sessions
      if (user?.role === 'consultant') {
        const assessments = await storage.getAssessmentsByConsultant(userId);
        const allSessions = [];
        for (const assessment of assessments) {
          const sessions = await storage.getSessionsByAssessment(assessment.id);
          allSessions.push(...sessions);
        }
        return res.json(allSessions);
      }
      
      res.status(403).json({ message: "Forbidden" });
    } catch (error) {
      console.error("Error fetching sessions:", error);
      res.status(500).json({ message: "Failed to fetch sessions" });
    }
  });

  app.post('/api/sessions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'consultant') {
        return res.status(403).json({ message: "Forbidden - Consultant only" });
      }

      // Verify the assessment belongs to this consultant
      if (req.body.assessmentId) {
        const assessment = await storage.getAssessment(req.body.assessmentId);
        if (!assessment || assessment.consultantId !== userId) {
          return res.status(403).json({ message: "Forbidden - Assessment not assigned to you" });
        }
      }

      const validated = insertSessionSchema.parse({ ...req.body, consultantId: userId });
      const session = await storage.createSession(validated);
      res.status(201).json(session);
    } catch (error: any) {
      console.error("Error creating session:", error);
      const validationError = fromError(error);
      res.status(400).json({ message: validationError.toString() });
    }
  });

  app.get('/api/sessions/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      const session = await storage.getSession(req.params.id);
      if (!session) {
        return res.status(404).json({ message: "Session not found" });
      }

      // Authorization check: consultant can view their sessions, beneficiary can view sessions from their assessments
      if (user?.role === 'consultant' && session.consultantId !== userId) {
        return res.status(403).json({ message: "Forbidden - Not your session" });
      }

      if (user?.role === 'beneficiary') {
        const assessment = await storage.getAssessment(session.assessmentId);
        if (!assessment || assessment.beneficiaryId !== userId) {
          return res.status(403).json({ message: "Forbidden - Not your session" });
        }
      }

      res.json(session);
    } catch (error) {
      console.error("Error fetching session:", error);
      res.status(500).json({ message: "Failed to fetch session" });
    }
  });

  app.patch('/api/sessions/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'consultant') {
        return res.status(403).json({ message: "Forbidden - Consultant only" });
      }

      // Check session exists and belongs to this consultant
      const existingSession = await storage.getSession(req.params.id);
      if (!existingSession) {
        return res.status(404).json({ message: "Session not found" });
      }
      
      if (existingSession.consultantId !== userId) {
        return res.status(403).json({ message: "Forbidden - You can only edit your own sessions" });
      }

      // Validate request body - prevent consultant ID changes
      const validated = insertSessionSchema.partial().parse(req.body);
      if (validated.consultantId && validated.consultantId !== userId) {
        return res.status(403).json({ message: "Cannot change consultant ID" });
      }

      // If assessmentId is being changed, verify the new assessment belongs to this consultant
      if (validated.assessmentId && validated.assessmentId !== existingSession.assessmentId) {
        const newAssessment = await storage.getAssessment(validated.assessmentId);
        if (!newAssessment || newAssessment.consultantId !== userId) {
          return res.status(403).json({ message: "Forbidden - Assessment not assigned to you" });
        }
      }

      const session = await storage.updateSession(req.params.id, validated);
      if (!session) {
        return res.status(404).json({ message: "Session not found" });
      }
      res.json(session);
    } catch (error: any) {
      console.error("Error updating session:", error);
      if (error.name === 'ZodError') {
        const validationError = fromError(error);
        return res.status(400).json({ message: validationError.toString() });
      }
      res.status(500).json({ message: "Failed to update session" });
    }
  });

  app.delete('/api/sessions/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'consultant') {
        return res.status(403).json({ message: "Forbidden - Consultant only" });
      }

      // Check session exists and belongs to this consultant
      const existingSession = await storage.getSession(req.params.id);
      if (!existingSession) {
        return res.status(404).json({ message: "Session not found" });
      }
      
      if (existingSession.consultantId !== userId) {
        return res.status(403).json({ message: "Forbidden - You can only delete your own sessions" });
      }

      await storage.deleteSession(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting session:", error);
      res.status(500).json({ message: "Failed to delete session" });
    }
  });

  // Consultant routes
  app.get('/api/consultant/assessments', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (user?.role !== 'consultant') {
        return res.status(403).json({ message: "Forbidden" });
      }
      const assessments = await storage.getAssessmentsByConsultant(userId);
      res.json(assessments);
    } catch (error) {
      console.error("Error fetching consultant assessments:", error);
      res.status(500).json({ message: "Failed to fetch assessments" });
    }
  });

  app.get('/api/consultant/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (user?.role !== 'consultant') {
        return res.status(403).json({ message: "Forbidden" });
      }
      const assessments = await storage.getAssessmentsByConsultant(userId);
      const now = new Date();
      const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      
      const stats = {
        totalActive: assessments.filter(a => a.status === 'in_progress').length,
        completedThisMonth: assessments.filter(a => 
          a.status === 'completed' && 
          a.updatedAt && 
          new Date(a.updatedAt) >= thisMonthStart
        ).length,
        upcomingSessions: assessments.reduce((sum, a) => 
          sum + (a.sessions?.filter(s => s.scheduledDate && new Date(s.scheduledDate) > now).length || 0), 0
        ),
        averageProgress: assessments.length > 0 
          ? Math.round(assessments.reduce((sum, a) => sum + (a.progressPercentage || 0), 0) / assessments.length)
          : 0,
      };
      res.json(stats);
    } catch (error) {
      console.error("Error fetching consultant stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Admin routes
  app.get('/api/admin/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Forbidden" });
      }
      const assessments = await storage.getAllAssessments();
      const consultants = await storage.getUserByRole('consultant');
      const now = new Date();
      const thisMonthStart = new Date(now.getFullYear(), now.getMonth(), 1);
      
      const stats = {
        totalAssessments: assessments.length,
        activeAssessments: assessments.filter(a => a.status === 'in_progress').length,
        totalConsultants: consultants.length,
        completedThisMonth: assessments.filter(a => 
          a.status === 'completed' && 
          a.updatedAt && 
          new Date(a.updatedAt) >= thisMonthStart
        ).length,
        averageCompletionRate: assessments.length > 0
          ? Math.round((assessments.filter(a => a.status === 'completed').length / assessments.length) * 100)
          : 0,
        qualipiCompliance: 95, // Placeholder
      };
      res.json(stats);
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  app.get('/api/admin/recent-assessments', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Forbidden" });
      }
      const assessments = await storage.getAllAssessments();
      res.json(assessments.slice(0, 10));
    } catch (error) {
      console.error("Error fetching recent assessments:", error);
      res.status(500).json({ message: "Failed to fetch assessments" });
    }
  });

  // Skills routes
  app.get('/api/skills', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const assessments = await storage.getAssessmentsByBeneficiary(userId);
      const activeAssessment = assessments.find(a => a.status !== 'completed' && a.status !== 'cancelled');
      
      if (!activeAssessment) {
        return res.json([]);
      }
      
      const skills = await storage.getSkillsByAssessment(activeAssessment.id);
      res.json(skills);
    } catch (error) {
      console.error("Error fetching skills:", error);
      res.status(500).json({ message: "Failed to fetch skills" });
    }
  });

  app.post('/api/skills', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const assessments = await storage.getAssessmentsByBeneficiary(userId);
      const activeAssessment = assessments.find(a => a.status !== 'completed' && a.status !== 'cancelled');
      
      if (!activeAssessment) {
        return res.status(400).json({ message: "No active assessment found" });
      }

      const validated = insertSkillSchema.parse({ ...req.body, assessmentId: activeAssessment.id });
      const skill = await storage.createSkill(validated);
      res.status(201).json(skill);
    } catch (error: any) {
      console.error("Error creating skill:", error);
      const validationError = fromError(error);
      res.status(400).json({ message: validationError.toString() });
    }
  });

  app.delete('/api/skills/:id', isAuthenticated, async (req: any, res) => {
    try {
      await storage.deleteSkill(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting skill:", error);
      res.status(500).json({ message: "Failed to delete skill" });
    }
  });

  // Questionnaire routes
  app.get('/api/questionnaires', isAuthenticated, async (req: any, res) => {
    try {
      const { phase } = req.query;
      const questionnaires = phase
        ? await storage.getQuestionnairesByPhase(phase)
        : await storage.getAllActiveQuestionnaires();
      res.json(questionnaires);
    } catch (error) {
      console.error("Error fetching questionnaires:", error);
      res.status(500).json({ message: "Failed to fetch questionnaires" });
    }
  });

  app.get('/api/questionnaires/:id', isAuthenticated, async (req: any, res) => {
    try {
      const questionnaire = await storage.getQuestionnaire(req.params.id);
      if (!questionnaire) {
        return res.status(404).json({ message: "Questionnaire not found" });
      }
      res.json(questionnaire);
    } catch (error) {
      console.error("Error fetching questionnaire:", error);
      res.status(500).json({ message: "Failed to fetch questionnaire" });
    }
  });

  app.post('/api/questionnaires', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Forbidden - Admin only" });
      }

      const validated = insertQuestionnaireSchema.parse(req.body);
      const questionnaire = await storage.createQuestionnaire(validated);
      res.status(201).json(questionnaire);
    } catch (error: any) {
      console.error("Error creating questionnaire:", error);
      const validationError = fromError(error);
      res.status(400).json({ message: validationError.toString() });
    }
  });

  app.post('/api/questionnaires/:id/questions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (user?.role !== 'admin') {
        return res.status(403).json({ message: "Forbidden - Admin only" });
      }

      const validated = insertQuestionnaireQuestionSchema.parse({
        ...req.body,
        questionnaireId: req.params.id,
      });
      const question = await storage.createQuestion(validated);
      res.status(201).json(question);
    } catch (error: any) {
      console.error("Error creating question:", error);
      const validationError = fromError(error);
      res.status(400).json({ message: validationError.toString() });
    }
  });

  // Questionnaire Response routes
  app.get('/api/responses', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const { assessmentId } = req.query;
      if (!assessmentId) {
        return res.status(400).json({ message: "assessmentId is required" });
      }

      // Verify user has access to this assessment
      const assessment = await storage.getAssessment(assessmentId as string);
      if (!assessment || (assessment.beneficiaryId !== userId && assessment.consultantId !== userId)) {
        return res.status(403).json({ message: "Forbidden - Not your assessment" });
      }

      const responses = await storage.getResponsesByAssessment(assessmentId as string);
      res.json(responses);
    } catch (error) {
      console.error("Error fetching responses:", error);
      res.status(500).json({ message: "Failed to fetch responses" });
    }
  });

  app.get('/api/responses/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const response = await storage.getResponse(req.params.id);
      if (!response) {
        return res.status(404).json({ message: "Response not found" });
      }

      // Verify user has access to this response
      if (response.beneficiaryId !== userId) {
        const assessment = await storage.getAssessment(response.assessmentId);
        if (!assessment || assessment.consultantId !== userId) {
          return res.status(403).json({ message: "Forbidden - Not your response" });
        }
      }

      res.json(response);
    } catch (error) {
      console.error("Error fetching response:", error);
      res.status(500).json({ message: "Failed to fetch response" });
    }
  });

  app.post('/api/responses', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;

      // Verify the assessment belongs to this beneficiary
      if (req.body.assessmentId) {
        const assessment = await storage.getAssessment(req.body.assessmentId);
        if (!assessment || assessment.beneficiaryId !== userId) {
          return res.status(403).json({ message: "Forbidden - Assessment not assigned to you" });
        }
      }

      const validated = insertQuestionnaireResponseSchema.parse({
        ...req.body,
        beneficiaryId: userId,
      });
      const response = await storage.createResponse(validated);
      res.status(201).json(response);
    } catch (error: any) {
      console.error("Error creating response:", error);
      const validationError = fromError(error);
      res.status(400).json({ message: validationError.toString() });
    }
  });

  app.patch('/api/responses/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;

      // Check existing response and verify ownership
      const existingResponse = await storage.getResponse(req.params.id);
      if (!existingResponse) {
        return res.status(404).json({ message: "Response not found" });
      }

      if (existingResponse.beneficiaryId !== userId) {
        return res.status(403).json({ message: "Forbidden - Not your response" });
      }

      const validated = insertQuestionnaireResponseSchema.partial().parse(req.body);
      const response = await storage.updateResponse(req.params.id, validated);
      if (!response) {
        return res.status(404).json({ message: "Response not found" });
      }
      res.json(response);
    } catch (error: any) {
      console.error("Error updating response:", error);
      const validationError = fromError(error);
      res.status(400).json({ message: validationError.toString() });
    }
  });

  // Questionnaire Answer routes
  app.post('/api/answers', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;

      // Verify the response belongs to this beneficiary
      if (req.body.responseId) {
        const response = await storage.getResponse(req.body.responseId);
        if (!response || response.beneficiaryId !== userId) {
          return res.status(403).json({ message: "Forbidden - Response not yours" });
        }
      }

      const validated = insertQuestionnaireAnswerSchema.parse(req.body);
      const answer = await storage.createAnswer(validated);
      res.status(201).json(answer);
    } catch (error: any) {
      console.error("Error creating answer:", error);
      const validationError = fromError(error);
      res.status(400).json({ message: validationError.toString() });
    }
  });

  app.patch('/api/answers/:id', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;

      // Get the answer to find the response it belongs to
      const existingAnswer = await storage.getAnswer(req.params.id);
      if (!existingAnswer) {
        return res.status(404).json({ message: "Answer not found" });
      }

      // Verify the response belongs to this beneficiary
      const response = await storage.getResponse(existingAnswer.responseId);
      if (!response || response.beneficiaryId !== userId) {
        return res.status(403).json({ message: "Forbidden - Not your answer" });
      }

      const validated = insertQuestionnaireAnswerSchema.partial().parse(req.body);
      const answer = await storage.updateAnswer(req.params.id, validated);
      if (!answer) {
        return res.status(404).json({ message: "Answer not found" });
      }
      res.json(answer);
    } catch (error: any) {
      console.error("Error updating answer:", error);
      const validationError = fromError(error);
      res.status(400).json({ message: validationError.toString() });
    }
  });

  // AI Analysis routes
  app.post('/api/ai/analyze-skills', isAuthenticated, async (req: any, res) => {
    try {
      const { assessmentId } = req.body;
      const assessment = await storage.getAssessment(assessmentId);
      
      if (!assessment || !assessment.skills || assessment.skills.length === 0) {
        return res.status(400).json({ message: "No skills found for analysis" });
      }

      const analysis = await analyzeSkills(assessment.skills, assessment.objectives || undefined);
      
      // Save analysis to database
      await storage.createAiAnalysis({
        assessmentId,
        analysisType: 'skills_analysis',
        inputData: { skills: assessment.skills },
        outputData: analysis,
        recommendations: analysis.strengthsAnalysis,
        transferableSkills: analysis.transferableSkills,
        careerPaths: analysis.careerRecommendations,
      });

      res.json(analysis);
    } catch (error) {
      console.error("Error analyzing skills:", error);
      res.status(500).json({ message: "Failed to analyze skills" });
    }
  });

  app.post('/api/ai/career-paths', isAuthenticated, async (req: any, res) => {
    try {
      const { assessmentId } = req.body;
      const assessment = await storage.getAssessment(assessmentId);
      
      if (!assessment || !assessment.skills || assessment.skills.length === 0) {
        return res.status(400).json({ message: "No skills found for analysis" });
      }

      const careerPaths = await generateCareerPaths(assessment.skills, assessment.objectives || undefined);
      
      res.json(careerPaths);
    } catch (error) {
      console.error("Error generating career paths:", error);
      res.status(500).json({ message: "Failed to generate career paths" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
