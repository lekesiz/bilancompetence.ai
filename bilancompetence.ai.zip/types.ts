export enum UserRole {
  BENEFICIARY = 'Bénéficiaire',
  CONSULTANT = 'Consultant',
  ADMIN = 'Administrateur',
}

export enum BilanStatus {
  PRELIMINARY = 'Préliminaire',
  INVESTIGATION = 'Investigation',
  CONCLUSION = 'Conclusion',
  COMPLETED = 'Terminé',
}

export enum SkillLevel {
  BEGINNER = 'Débutant',
  INTERMEDIATE = 'Intermédiaire',
  ADVANCED = 'Avancé',
  EXPERT = 'Expert',
}

export enum SkillInterest {
  LIKE = 'Aime',
  NEUTRAL = 'Neutre',
  DISLIKE = "N'aime pas",
}

export enum QualiopiStatus {
    TODO = 'À faire',
    IN_PROGRESS = 'En cours',
    DONE = 'Terminé',
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatarUrl?: string;
}

export interface Skill {
  id: string;
  name: string;
  category: string;
}

export interface AssessedSkill {
  skillId: string;
  level: SkillLevel | null;
  interest: SkillInterest | null;
  beneficiaryNotes: string;
  consultantValidation: boolean;
}

export interface Message {
    id: string;
    senderId: string;
    content: string;
    timestamp: Date;
}

export interface Appointment {
    id: string;
    consultantId: string;
    beneficiaryId: string;
    date: Date;
    durationMinutes: number;
    title: string;
    status: 'confirmed' | 'pending';
    notes?: string;
}

export interface QualiopiTask {
    id: string;
    indicator: string;
    description: string;
    status: QualiopiStatus;
}

export interface Document {
    id: string;
    name: string;
    fileType: 'pdf' | 'docx' | 'png' | 'jpeg';
    sizeKB: number;
    uploadDate: Date;
    uploaderId: string;
}

export interface JobOffer {
    id: string;
    title: string;
    company: string;
    location: string;
    contractType: 'CDI' | 'CDD' | 'Alternance' | 'Intérim' | 'Indépendant';
    description: string;
    requiredSkills: string[];
}

export interface Bilan {
  id: string;
  beneficiaryId: string;
  consultantId: string;
  status: BilanStatus;
  startDate: Date;
  endDate: Date;
  assessedSkills: AssessedSkill[];
  messages: Message[];
  appointments: Appointment[];
  qualiopiTasks: QualiopiTask[];
  documents: Document[];
  synthesisContent: string | null;
  jobOffers: JobOffer[] | null;
}


// MOCK DATA

export const USERS: User[] = [
  { id: 'user-1', name: 'Alice Martin', email: 'alice.martin@example.com', role: UserRole.BENEFICIARY, avatarUrl: 'https://i.pravatar.cc/150?u=user-1' },
  { id: 'user-2', name: 'Dr. Bernard Dubois', email: 'bernard.dubois@conseil.com', role: UserRole.CONSULTANT, avatarUrl: 'https://i.pravatar.cc/150?u=user-2' },
  { id: 'user-3', name: 'Carla Petit', email: 'carla.petit@example.com', role: UserRole.BENEFICIARY, avatarUrl: 'https://i.pravatar.cc/150?u=user-3' },
  { id: 'user-4', name: 'David Lefebvre', email: 'david.lefebvre@example.com', role: UserRole.BENEFICIARY, avatarUrl: 'https://i.pravatar.cc/150?u=user-4' },
  { id: 'user-5', name: 'Émilie Girard', email: 'emilie.girard@conseil.com', role: UserRole.CONSULTANT, avatarUrl: 'https://i.pravatar.cc/150?u=user-5' },
  { id: 'user-6', name: 'Franck Royer', email: 'franck.royer@admin.com', role: UserRole.ADMIN, avatarUrl: 'https://i.pravatar.cc/150?u=user-6' },
  { id: 'user-7', name: 'Georges Lemoine', email: 'georges.lemoine@example.com', role: UserRole.BENEFICIARY, avatarUrl: 'https://i.pravatar.cc/150?u=user-7' },
];

export const SKILLS: Skill[] = [
    { id: 'skill-1', name: 'Gestion de projet Agile', category: 'Management' },
    { id: 'skill-2', name: 'React & TypeScript', category: 'Développement Web' },
    { id: 'skill-3', name: 'Communication Interpersonnelle', category: 'Soft Skills' },
    { id: 'skill-4', name: 'Analyse de données (SQL, Python)', category: 'Analyse' },
    { id: 'skill-5', name: 'Design UI/UX (Figma)', category: 'Design' },
    { id: 'skill-6', name: 'Marketing Digital (SEO, SEA)', category: 'Marketing' },
    { id: 'skill-7', name: 'Leadership & Management d\'équipe', category: 'Management' },
    { id: 'skill-8', name: 'Node.js & Express', category: 'Développement Web' },
    { id: 'skill-9', name: 'Résolution de problèmes complexes', category: 'Soft Skills' },
    { id: 'skill-10', name: 'Cloud Computing (AWS/GCP)', category: 'Infrastructure' },
];

export const generateQualiopiTasks = (): QualiopiTask[] => [
    { id: 'q-1', indicator: 'Ind. 1', description: 'Information du public sur les prestations', status: QualiopiStatus.DONE },
    { id: 'q-2', indicator: 'Ind. 10', description: 'Adaptation de la prestation', status: QualiopiStatus.IN_PROGRESS },
    { id: 'q-3', indicator: 'Ind. 11', description: 'Évaluation des acquis et de la satisfaction', status: QualiopiStatus.TODO },
    { id: 'q-4', indicator: 'Ind. 22', description: 'Traçabilité des actions', status: QualiopiStatus.TODO },
    { id: 'q-5', indicator: 'Ind. 30', description: 'Recueil des appréciations', status: QualiopiStatus.TODO },
];

export const BILANS: Bilan[] = [
    {
        id: 'bilan-1',
        beneficiaryId: 'user-1',
        consultantId: 'user-2',
        status: BilanStatus.INVESTIGATION,
        startDate: new Date('2025-10-01'),
        endDate: new Date('2025-12-15'),
        assessedSkills: [
            { skillId: 'skill-1', level: SkillLevel.ADVANCED, interest: SkillInterest.LIKE, beneficiaryNotes: 'Plusieurs projets menés à bien en environnement Scrum.', consultantValidation: true },
            { skillId: 'skill-2', level: SkillLevel.INTERMEDIATE, interest: SkillInterest.LIKE, beneficiaryNotes: 'Utilisé sur des projets personnels et un projet en entreprise.', consultantValidation: false },
            { skillId: 'skill-3', level: SkillLevel.EXPERT, interest: SkillInterest.LIKE, beneficiaryNotes: 'Très à l\'aise en public et en réunion.', consultantValidation: true },
            { skillId: 'skill-4', level: null, interest: null, beneficiaryNotes: '', consultantValidation: false },
            { skillId: 'skill-6', level: null, interest: null, beneficiaryNotes: '', consultantValidation: false },
        ],
        messages: [
            { id: 'msg-1-1', senderId: 'user-2', content: 'Bonjour Alice, n\'oubliez pas de remplir votre auto-évaluation pour les compétences restantes avant notre RDV de demain. Cela nous permettra d\'avancer efficacement.', timestamp: new Date(new Date().setDate(new Date().getDate() - 1)) },
            { id: 'msg-1-2', senderId: 'user-1', content: 'Bonjour Dr. Dubois, c\'est noté ! Je m\'en occupe ce soir sans faute. Merci pour le rappel.', timestamp: new Date(new Date().getTime() - 23 * 3600 * 1000) },
        ],
        appointments: [
            { id: 'apt-1-1', consultantId: 'user-2', beneficiaryId: 'user-1', date: new Date(new Date().setDate(new Date().getDate() + 1)), durationMinutes: 60, title: 'Session 3 - Phase d\'investigation', status: 'confirmed' },
            { id: 'apt-1-2', consultantId: 'user-2', beneficiaryId: 'user-1', date: new Date(new Date().setDate(new Date().getDate() + 8)), durationMinutes: 90, title: 'Session 4 - Exploration des pistes', status: 'confirmed' }
        ],
        qualiopiTasks: generateQualiopiTasks(),
        documents: [
            { id: 'doc-1', name: 'CV_Alice_Martin_2025.pdf', fileType: 'pdf', sizeKB: 128, uploadDate: new Date('2025-10-02'), uploaderId: 'user-1' },
            { id: 'doc-2', name: 'Resultats_Test_Orientation.docx', fileType: 'docx', sizeKB: 45, uploadDate: new Date('2025-10-10'), uploaderId: 'user-2' },
        ],
        synthesisContent: null,
        jobOffers: null,
    },
    {
        id: 'bilan-2',
        beneficiaryId: 'user-3',
        consultantId: 'user-2',
        status: BilanStatus.CONCLUSION,
        startDate: new Date('2025-09-15'),
        endDate: new Date('2025-11-30'),
        assessedSkills: [
             { skillId: 'skill-5', level: SkillLevel.ADVANCED, interest: SkillInterest.LIKE, beneficiaryNotes: 'Passionnée par le design centré utilisateur.', consultantValidation: true },
             { skillId: 'skill-9', level: SkillLevel.INTERMEDIATE, interest: SkillInterest.NEUTRAL, beneficiaryNotes: 'J\'aime les défis logiques.', consultantValidation: true },
        ],
        messages: [],
        appointments: [
            { id: 'apt-2-1', consultantId: 'user-2', beneficiaryId: 'user-3', date: new Date(new Date().setDate(new Date().getDate() + 3)), durationMinutes: 60, title: 'Session de conclusion', status: 'confirmed' }
        ],
        qualiopiTasks: generateQualiopiTasks().map(t => ({...t, status: QualiopiStatus.DONE })),
        documents: [],
        synthesisContent: `### Document de Synthèse - Carla Petit

**1. Analyse du Parcours et des Compétences**
Carla dispose d'une expertise reconnue en Design UI/UX, validée par son portfolio et ses expériences. Sa passion pour le design centré utilisateur est un atout majeur.

**2. Pistes de Projets Professionnels**
- **Lead UX Designer** : Évoluer vers un rôle de management et de stratégie UX.
- **Product Owner** : Mettre à profit ses compétences en UX pour piloter le développement de produits.

**3. Plan d'Action**
- **Objectif Principal** : Obtenir un poste de Lead UX Designer en 6 mois.
- **Étape 1** : Suivre une formation en management (certifiante).
- **Étape 2** : Mettre à jour son portfolio avec des études de cas stratégiques.`,
        jobOffers: null,
    },
     {
        id: 'bilan-3',
        beneficiaryId: 'user-4',
        consultantId: 'user-5',
        status: BilanStatus.COMPLETED,
        startDate: new Date('2025-07-01'),
        endDate: new Date('2025-09-10'),
        assessedSkills: [],
        messages: [],
        appointments: [],
        qualiopiTasks: generateQualiopiTasks().map(t => ({...t, status: QualiopiStatus.DONE })),
        documents: [],
        synthesisContent: `Bilan terminé avec succès. Projet de reconversion vers le marketing digital validé.`,
        jobOffers: null,
    },
];
