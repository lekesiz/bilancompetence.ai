import { GoogleGenAI, Type } from "@google/genai";
import { AssessedSkill, Bilan, JobOffer, Skill, User } from '../types';

// The API key is expected to be provided by the execution environment.
// A placeholder is used here to allow the code to be structured correctly.
const API_KEY = process.env.API_KEY || "YOUR_API_KEY_HERE";
const ai = new GoogleGenAI({ apiKey: API_KEY });

const handleError = (error: unknown, context?: string): string => {
    console.error(`Error calling Gemini API${context ? ` in ${context}` : ''}:`, error);
    if (error instanceof Error) {
        if (error.message.includes('API key not valid') || error.message.includes('API_KEY_INVALID')) {
            return "## Erreur de Configuration\n\nLa clé API fournie n'est pas valide. Veuillez contacter l'administrateur de la plateforme. Le service IA est actuellement indisponible.";
        }
    }
    return "## Erreur Inattendue\n\nUne erreur est survenue lors de la communication avec le service d'intelligence artificielle. Veuillez réessayer plus tard.";
}

const formatSkillsForPrompt = (assessedSkills: AssessedSkill[], allSkills: Skill[]): string => {
    return assessedSkills
        .filter(as => as.level && as.interest) // Only include skills that have been assessed
        .map(as => {
            const skill = allSkills.find(s => s.id === as.skillId);
            if (!skill) return '';
            return `- **Compétence**: ${skill.name} (*Catégorie: ${skill.category}*)
  - **Niveau auto-évalué**: ${as.level}
  - **Appétence**: ${as.interest}
  - **Notes du bénéficiaire**: ${as.beneficiaryNotes || 'Aucune'}
  - **Validé par le consultant**: ${as.consultantValidation ? 'Oui' : 'Non'}`;
        })
        .join('\n');
};

export const generateBilanSynthesis = async (
    bilan: Bilan,
    beneficiary: User,
    allSkills: Skill[]
): Promise<string> => {
    
    const formattedSkills = formatSkillsForPrompt(bilan.assessedSkills, allSkills);

    const prompt = `
En tant que consultant expert en bilan de compétences, rédigez un document de synthèse professionnel, structuré et bienveillant pour **${beneficiary.name}**. 
Le document doit être au format **Markdown** et doit inclure les sections suivantes :
1.  **Analyse du Parcours et des Compétences** : Résumez les points forts et les compétences clés identifiées.
2.  **Analyse des Motivations et Intérêts** : Analysez les motivations profondes basées sur les appétences.
3.  **Pistes de Projets Professionnels** : Proposez 2 ou 3 pistes de projets réalistes et argumentées.
4.  **Plan d'Action SMART** : Élaborez un plan d'action détaillé pour la piste la plus prometteuse.
5.  **Conclusion** : Terminez par un paragraphe encourageant.

Voici les informations collectées :
Bénéficiaire : ${beneficiary.name}

---
### Compétences Évaluées
${formattedSkills}
---

Rédigez maintenant la synthèse complète en suivant la structure demandée.
`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        return response.text;
    } catch (error) {
        return handleError(error, 'generateBilanSynthesis');
    }
};

export const generateCareerInsights = async (
    assessedSkills: AssessedSkill[], 
    allSkills: Skill[]
): Promise<string> => {
    const formattedSkills = formatSkillsForPrompt(assessedSkills, allSkills);
     const prompt = `
En tant qu'expert en orientation de carrière, analysez le profil de compétences suivant et fournissez des pistes de réflexion approfondies au format **Markdown**.

### Profil de Compétences
${formattedSkills}

---

Veuillez générer les sections suivantes :

### 1. Métiers Potentiels
Suggérez 3 à 5 métiers ou rôles qui correspondent bien à ce profil. Pour chaque métier, expliquez brièvement pourquoi il est pertinent (ex: "Data Analyst, car vous combinez une compétence en analyse de données avec un intérêt pour la résolution de problèmes complexes").

### 2. Compétences à Développer
Identifiez 2 ou 3 compétences clés qui, si développées, pourraient ouvrir de nouvelles opportunités ou renforcer l'attractivité du profil. Suggérez des types de formations (en ligne, certifiantes, etc.).

### 3. Secteurs d'Activité Porteurs
Listez 3 secteurs d'activité où ce profil de compétences serait particulièrement recherché (ex: Tech, Santé, Énergie renouvelable) et expliquez pourquoi.
`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        return response.text;
    } catch (error) {
        return handleError(error, 'generateCareerInsights');
    }
};

export const findJobOffers = async (
    assessedSkills: AssessedSkill[],
    allSkills: Skill[]
): Promise<JobOffer[]> => {
    const formattedSkills = formatSkillsForPrompt(assessedSkills, allSkills);
    const prompt = `
En tant qu'assistant de carrière connecté à la base de données de France Travail, identifiez 3 à 5 offres d'emploi pertinentes en France basées sur le profil de compétences suivant. Les offres doivent être réalistes et variées.

### Profil de Compétences
${formattedSkills}

---
Retournez le résultat exclusivement au format JSON.
`;

    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        jobOffers: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    id: { type: Type.STRING },
                                    title: { type: Type.STRING },
                                    company: { type: Type.STRING },
                                    location: { type: Type.STRING },
                                    contractType: { type: Type.STRING, enum: ['CDI', 'CDD', 'Alternance', 'Intérim', 'Indépendant'] },
                                    description: { type: Type.STRING },
                                    requiredSkills: { type: Type.ARRAY, items: { type: Type.STRING } },
                                },
                                required: ['id', 'title', 'company', 'location', 'contractType', 'description', 'requiredSkills']
                            }
                        }
                    }
                }
            }
        });

        const jsonStr = response.text.trim();
        const parsed = JSON.parse(jsonStr);
        // Add a random ID if the model fails to generate one
        return (parsed.jobOffers || []).map((offer: JobOffer) => ({ ...offer, id: offer.id || `offer-${Math.random()}` }));
    } catch (error) {
        console.error("Error finding job offers:", error);
        return [];
    }
};


export const analyzeCVForSkills = async (cvText: string): Promise<string[]> => {
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: `Extrais les compétences techniques (hard skills) et comportementales (soft skills) du texte de CV suivant. Ignore les informations personnelles. Retourne le résultat sous forme d'un tableau JSON de chaînes de caractères. Exemple: ["Gestion de projet", "React", "Communication"]. CV: "${cvText}"`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        skills: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.STRING
                            }
                        }
                    }
                }
            }
        });

        const jsonStr = response.text.trim();
        const parsed = JSON.parse(jsonStr);
        return parsed.skills || [];
    } catch (error) {
        console.error("Error analyzing CV:", error);
        return [];
    }
};
