import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { Bilan, User, UserRole, USERS, BILANS, SKILLS, AssessedSkill, SkillLevel, SkillInterest, BilanStatus, Skill, Message, Appointment, QualiopiTask, QualiopiStatus, Document, generateQualiopiTasks, JobOffer } from './types';
import { Button, Card, Spinner, Modal, ProgressBar, Tabs, Input, Textarea, ConfirmationModal } from './components/UI';
import { ArrowLeftOnRectangleIcon, BriefcaseIcon, CheckCircleIcon, DocumentTextIcon, SparklesIcon, UserCircleIcon, XCircleIcon, ChartBarIcon, CalendarDaysIcon, ChatBubbleLeftRightIcon, ShieldCheckIcon, LightBulbIcon, PlusIcon, PaperAirplaneIcon, ArrowUpOnSquareIcon, ClipboardDocumentIcon, TrashIcon, PencilIcon, FolderIcon, ArrowUpTrayIcon, DocumentArrowDownIcon, MagnifyingGlassIcon } from './components/Icons';
import { generateBilanSynthesis, generateCareerInsights, analyzeCVForSkills, findJobOffers } from './services/geminiService';

declare var markdownit: any;
const md = new markdownit();

// --- HELPER & GENERIC COMPONENTS ---

const Header: React.FC<{ user: User; onLogout: () => void }> = ({ user, onLogout }) => (
  <header className="bg-white shadow-md sticky top-0 z-40">
    <div className="container mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex justify-between items-center h-16">
        <div className="flex items-center space-x-3">
          <BriefcaseIcon className="h-8 w-8 text-brand-primary" />
          <h1 className="text-xl font-bold text-slate-800">BilanCompetence.AI</h1>
        </div>
        <div className="flex items-center space-x-4">
          <div className="text-right">
            <p className="font-semibold text-slate-700">{user.name}</p>
            <p className="text-sm text-slate-500">{user.role}</p>
          </div>
          <button onClick={onLogout} title="Se déconnecter" className="text-slate-500 hover:text-brand-primary transition-colors">
            <ArrowLeftOnRectangleIcon className="h-6 w-6" />
          </button>
        </div>
      </div>
    </div>
  </header>
);

const LoginScreen: React.FC<{ onLogin: (user: User) => void }> = ({ onLogin }) => (
    <div className="min-h-screen bg-slate-100 flex flex-col justify-center items-center p-4">
      <div className="w-full max-w-md">
        <Card className="p-8">
          <div className="text-center mb-8">
            <BriefcaseIcon className="h-16 w-16 text-brand-primary mx-auto" />
            <h2 className="mt-4 text-3xl font-extrabold text-slate-900">BilanCompetence.AI</h2>
            <p className="mt-2 text-slate-600">Digitalisez et modernisez vos bilans de compétences.</p>
          </div>
          <div className="space-y-4">
            <p className="text-sm text-center text-slate-500 font-medium">Choisissez un profil pour simuler la connexion :</p>
            {USERS.map(user => (
              <button
                key={user.id}
                onClick={() => onLogin(user)}
                className="w-full flex items-center space-x-4 p-3 rounded-lg bg-slate-50 hover:bg-brand-light border border-slate-200 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-brand-primary"
              >
                <img src={user.avatarUrl} alt={user.name} className="h-10 w-10 rounded-full" />
                <div className="text-left">
                  <p className="font-semibold text-slate-800">{user.name}</p>
                  <p className="text-sm text-slate-500">{user.role}</p>
                </div>
              </button>
            ))}
          </div>
        </Card>
      </div>
    </div>
);

const BilanCard: React.FC<{ bilan: Bilan; onSelect: () => void; userRole: UserRole }> = ({ bilan, onSelect, userRole }) => {
    const beneficiary = USERS.find(u => u.id === bilan.beneficiaryId);
    const consultant = USERS.find(u => u.id === bilan.consultantId);

    const statusColors: { [key in BilanStatus]: string } = {
        [BilanStatus.PRELIMINARY]: 'bg-blue-100 text-blue-800',
        [BilanStatus.INVESTIGATION]: 'bg-yellow-100 text-yellow-800',
        [BilanStatus.CONCLUSION]: 'bg-purple-100 text-purple-800',
        [BilanStatus.COMPLETED]: 'bg-green-100 text-green-800',
    };
    
    const totalTasks = bilan.qualiopiTasks.length;
    const completedTasks = bilan.qualiopiTasks.filter(t => t.status === QualiopiStatus.DONE).length;
    const progress = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

    return (
        <Card className="hover:shadow-lg transition-shadow duration-300 flex flex-col">
          <div className="p-6 flex-grow">
            <div className="flex justify-between items-start">
                <div>
                    <h3 className="text-lg font-bold text-brand-primary">{userRole === UserRole.BENEFICIARY ? "Mon Bilan de Compétences" : beneficiary?.name}</h3>
                    <p className="text-sm text-slate-500">Avec {userRole === UserRole.BENEFICIARY ? consultant?.name : 'vous'}</p>
                </div>
                <span className={`px-2 py-1 text-xs font-semibold rounded-full ${statusColors[bilan.status]}`}>
                    {bilan.status}
                </span>
            </div>
            <div className="mt-4 text-sm text-slate-600">
                <p>Début: {bilan.startDate.toLocaleDateString('fr-FR')}</p>
                <p>Fin prévue: {bilan.endDate.toLocaleDateString('fr-FR')}</p>
            </div>
            <div className='mt-4'>
                <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium text-slate-600">Progression</span>
                    <span className="text-sm font-medium text-slate-600">{Math.round(progress)}%</span>
                </div>
                <ProgressBar value={progress} />
            </div>
          </div>
          <div className="bg-slate-50 p-4 text-right">
             <Button onClick={onSelect}>Gérer le bilan</Button>
          </div>
        </Card>
    );
}

const StatCard: React.FC<{ title: string; value: string; icon: React.ReactNode }> = ({ title, value, icon }) => (
    <Card className="p-5">
        <div className="flex items-center">
            <div className="flex-shrink-0 bg-brand-light p-3 rounded-full">
                {icon}
            </div>
            <div className="ml-4">
                <p className="text-sm font-medium text-slate-500 truncate">{title}</p>
                <p className="text-2xl font-bold text-slate-900">{value}</p>
            </div>
        </div>
    </Card>
);

// --- BILAN DETAIL VIEW COMPONENTS ---

const CVAnalysisModal: React.FC<{ isOpen: boolean, onClose: () => void, onAddSkills: (skills: string[]) => void }> = ({ isOpen, onClose, onAddSkills }) => {
    const [cvText, setCvText] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [extractedSkills, setExtractedSkills] = useState<string[]>([]);
    
    const handleAnalyze = async () => {
        setIsLoading(true);
        const skills = await analyzeCVForSkills(cvText);
        setExtractedSkills(skills);
        setIsLoading(false);
    }

    const handleAddSkills = () => {
        onAddSkills(extractedSkills);
        onClose();
        setExtractedSkills([]);
        setCvText('');
    }

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Analyser un CV pour extraire les compétences">
            <div className="space-y-4">
                <p className="text-slate-600">Collez le contenu d'un CV ci-dessous. L'IA identifiera les compétences et vous pourrez les ajouter à votre bilan.</p>
                <Textarea 
                    rows={10} 
                    value={cvText} 
                    onChange={e => setCvText(e.target.value)} 
                    placeholder="Collez le texte de votre CV ici..." 
                />
                <Button onClick={handleAnalyze} disabled={isLoading || !cvText.trim()}>
                    {isLoading ? <Spinner size="sm" /> : <><SparklesIcon className="h-5 w-5 mr-2" /> Analyser</>}
                </Button>

                {extractedSkills.length > 0 && (
                    <div className="mt-4 p-4 bg-slate-50 rounded-md">
                        <h4 className="font-semibold mb-2">Compétences identifiées :</h4>
                        <div className="flex flex-wrap gap-2">
                            {extractedSkills.map(skill => <span key={skill} className="bg-brand-light text-brand-dark text-sm font-medium px-2 py-1 rounded-full">{skill}</span>)}
                        </div>
                        <div className="text-right mt-4">
                            <Button onClick={handleAddSkills}>
                                <PlusIcon className="h-5 w-5 mr-2" /> Ajouter ces compétences au bilan
                            </Button>
                        </div>
                    </div>
                )}
            </div>
        </Modal>
    )
}

const SkillsAssessment: React.FC<{ bilan: Bilan, onUpdateBilan: (updatedBilan: Bilan) => void, userRole: UserRole }> = ({ bilan, onUpdateBilan, userRole }) => {
    const isConsultant = userRole === UserRole.CONSULTANT;
    const [isCvModalOpen, setIsCvModalOpen] = useState(false);

    const handleUpdate = <K extends keyof AssessedSkill>(index: number, field: K, value: AssessedSkill[K]) => {
        const newSkills = [...bilan.assessedSkills];
        newSkills[index] = { ...newSkills[index], [field]: value };
        onUpdateBilan({ ...bilan, assessedSkills: newSkills });
    };

    const handleAddSkillsFromCV = (skills: string[]) => {
        const newAssessedSkills: AssessedSkill[] = [...bilan.assessedSkills];
        skills.forEach(skillName => {
            const existingSkill = SKILLS.find(s => s.name.toLowerCase() === skillName.toLowerCase());
            const alreadyAssessed = existingSkill && bilan.assessedSkills.some(as => as.skillId === existingSkill.id);
            
            if (existingSkill && !alreadyAssessed) {
                newAssessedSkills.push({
                    skillId: existingSkill.id,
                    level: null,
                    interest: null,
                    beneficiaryNotes: 'Ajouté via analyse CV',
                    consultantValidation: false
                });
            }
            // In a real app, we might create a new skill if it doesn't exist.
        });
        onUpdateBilan({ ...bilan, assessedSkills: newAssessedSkills });
    };
    
    return (
        <div className="space-y-6">
            <Card className="p-4 flex justify-between items-center">
                <div>
                    <h3 className="font-bold text-lg">Évaluation des Compétences</h3>
                    <p className="text-slate-500">Évaluez vos compétences et discutez-en avec votre consultant.</p>
                </div>
                {userRole === UserRole.BENEFICIARY && (
                    <Button onClick={() => setIsCvModalOpen(true)} variant="secondary">
                        <ArrowUpOnSquareIcon className="h-5 w-5 mr-2" /> Analyser un CV
                    </Button>
                )}
            </Card>

            {bilan.assessedSkills.map((as, index) => {
                const skill = SKILLS.find(s => s.id === as.skillId);
                if (!skill) return null;

                return (
                    <Card key={skill.id} className="p-4">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
                            <div className="md:col-span-1">
                                <h4 className="font-bold text-slate-800">{skill.name}</h4>
                                <p className="text-sm text-slate-500">{skill.category}</p>
                            </div>
                            <div className="md:col-span-2 space-y-4">
                                <div>
                                    <label className="block text-sm font-medium text-slate-700">Niveau de maîtrise</label>
                                    <select
                                        value={as.level || ''}
                                        onChange={(e) => handleUpdate(index, 'level', e.target.value as SkillLevel)}
                                        disabled={isConsultant}
                                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-primary focus:ring-brand-primary sm:text-sm disabled:bg-slate-100"
                                    >
                                        <option value="" disabled>-- Évaluez votre niveau --</option>
                                        {Object.values(SkillLevel).map(level => <option key={level} value={level}>{level}</option>)}
                                    </select>
                                </div>
                                 <div>
                                    <label className="block text-sm font-medium text-slate-700">Appétence</label>
                                    <div className="flex flex-wrap gap-x-4 gap-y-2 mt-1">
                                        {Object.values(SkillInterest).map(interest => (
                                            <label key={interest} className="flex items-center">
                                                <input
                                                    type="radio"
                                                    name={`interest-${skill.id}`}
                                                    value={interest}
                                                    checked={as.interest === interest}
                                                    onChange={(e) => handleUpdate(index, 'interest', e.target.value as SkillInterest)}
                                                    disabled={isConsultant}
                                                    className="focus:ring-brand-primary h-4 w-4 text-brand-primary border-gray-300 disabled:opacity-50"
                                                />
                                                <span className="ml-2 text-sm text-slate-600">{interest}</span>
                                            </label>
                                        ))}
                                    </div>
                                </div>
                                 <div>
                                    <label className="block text-sm font-medium text-slate-700">Notes / Contexte d'acquisition</label>
                                    <Textarea
                                        rows={2}
                                        value={as.beneficiaryNotes}
                                        onChange={(e) => handleUpdate(index, 'beneficiaryNotes', e.target.value)}
                                        disabled={isConsultant}
                                        placeholder='Ex: "Utilisé dans le projet X pour faire Y..."'
                                    />
                                </div>
                                {isConsultant && (
                                    <div className="flex items-center justify-end space-x-2 p-2 bg-slate-50 rounded-md">
                                        <label htmlFor={`validation-${skill.id}`} className="text-sm font-medium text-slate-700">Valider l'évaluation :</label>
                                        <input
                                            type="checkbox"
                                            id={`validation-${skill.id}`}
                                            checked={as.consultantValidation}
                                            onChange={(e) => handleUpdate(index, 'consultantValidation', e.target.checked)}
                                            className="h-5 w-5 rounded text-brand-primary focus:ring-brand-primary"
                                        />
                                        {as.consultantValidation ? <CheckCircleIcon className="h-6 w-6 text-green-500" /> : <XCircleIcon className="h-6 w-6 text-slate-400" />}
                                    </div>
                                )}
                            </div>
                        </div>
                    </Card>
                );
            })}
             <CVAnalysisModal isOpen={isCvModalOpen} onClose={() => setIsCvModalOpen(false)} onAddSkills={handleAddSkillsFromCV} />
        </div>
    );
};

const SynthesisGenerator: React.FC<{ bilan: Bilan; onUpdateBilan: (updatedBilan: Bilan) => void; userRole: UserRole }> = ({ bilan, onUpdateBilan, userRole }) => {
    const [isLoading, setIsLoading] = useState(false);
    const beneficiary = USERS.find(u => u.id === bilan.beneficiaryId);

    const handleGenerate = async () => {
        if (!beneficiary) return;
        setIsLoading(true);
        const result = await generateBilanSynthesis(bilan, beneficiary, SKILLS);
        onUpdateBilan({ ...bilan, synthesisContent: result });
        setIsLoading(false);
    };

    const handleCopyToClipboard = () => {
        if(bilan.synthesisContent) {
            navigator.clipboard.writeText(bilan.synthesisContent);
            // In a real app, show a toast notification here
            alert("Synthèse copiée dans le presse-papiers !");
        }
    }

    return (
        <Card>
            <div className="p-6">
                 <h3 className="text-xl font-bold mb-2">Synthèse & Plan d'action</h3>
                 <p className="text-slate-600 mb-6">Générez une proposition de document de synthèse avec l'IA. Ce document peut ensuite être finalisé et partagé avec le bénéficiaire.</p>
                <div className="text-center">
                    <Button onClick={handleGenerate} disabled={isLoading || userRole === UserRole.BENEFICIARY}>
                        {isLoading ? <Spinner size="sm" /> : (
                            <div className="flex items-center space-x-2">
                                <SparklesIcon className="h-5 w-5" />
                                <span>{bilan.synthesisContent ? 'Régénérer la synthèse' : 'Générer la synthèse'}</span>
                            </div>
                        )}
                    </Button>
                    {userRole === UserRole.BENEFICIARY && <p className="text-sm text-slate-500 mt-2">Seul votre consultant peut générer la synthèse.</p>}
                </div>

                {bilan.synthesisContent && (
                     <div className="mt-8">
                        <div className="flex justify-between items-center border-b pb-2 mb-4">
                            <h4 className="text-lg font-semibold">Document de Synthèse</h4>
                            <Button variant="ghost" size="sm" onClick={handleCopyToClipboard}>
                                <ClipboardDocumentIcon className="h-4 w-4 mr-2"/>
                                Copier
                            </Button>
                        </div>
                        <div className="prose prose-slate max-w-none p-4 bg-slate-50 rounded-md" dangerouslySetInnerHTML={{ __html: md.render(bilan.synthesisContent) }}>
                        </div>
                    </div>
                )}
            </div>
        </Card>
    );
};

const MessagingView: React.FC<{ bilan: Bilan; onUpdateBilan: (updatedBilan: Bilan) => void; currentUser: User }> = ({ bilan, onUpdateBilan, currentUser }) => {
    const [newMessage, setNewMessage] = useState('');
    const [messageToDelete, setMessageToDelete] = useState<Message | null>(null);
    const consultant = USERS.find(u => u.id === bilan.consultantId);
    const beneficiary = USERS.find(u => u.id === bilan.beneficiaryId);

    const handleSendMessage = (e: React.FormEvent) => {
        e.preventDefault();
        if(!newMessage.trim()) return;

        const message: Message = {
            id: `msg-${Date.now()}`,
            senderId: currentUser.id,
            content: newMessage,
            timestamp: new Date(),
        };
        const updatedBilan = { ...bilan, messages: [...bilan.messages, message]};
        onUpdateBilan(updatedBilan);
        setNewMessage('');
    }

    const handleConfirmDeleteMessage = () => {
        if (!messageToDelete) return;
        const updatedMessages = bilan.messages.filter(m => m.id !== messageToDelete.id);
        onUpdateBilan({ ...bilan, messages: updatedMessages });
        setMessageToDelete(null);
    };

    return (
        <Card className="flex flex-col h-[70vh]">
            <div className="p-4 border-b">
                <h3 className="text-xl font-bold">Messagerie</h3>
                <p className="text-sm text-slate-500">
                    Conversation avec {currentUser.role === UserRole.BENEFICIARY ? consultant?.name : beneficiary?.name}
                </p>
            </div>
            <div className="p-6 flex-grow overflow-y-auto bg-slate-50 flex flex-col space-y-4">
                {bilan.messages.map(msg => {
                    const sender = USERS.find(u => u.id === msg.senderId);
                    const isCurrentUser = msg.senderId === currentUser.id;
                    return (
                        <div key={msg.id} className={`flex items-end gap-3 ${isCurrentUser ? 'justify-end' : 'justify-start'}`}>
                             {!isCurrentUser && <img src={sender?.avatarUrl} alt={sender?.name} className="h-8 w-8 rounded-full" />}
                             
                             <div className={`flex items-center gap-2 ${isCurrentUser ? 'flex-row-reverse' : ''}`}>
                                <div className={`max-w-xs md:max-w-md p-3 rounded-lg ${isCurrentUser ? 'bg-brand-primary text-white' : 'bg-white'}`}>
                                    <p className="text-sm">{msg.content}</p>
                                    <p className={`text-xs mt-1 opacity-75 ${isCurrentUser ? 'text-indigo-200' : 'text-slate-400'}`}>{msg.timestamp.toLocaleTimeString('fr-FR', {hour: '2-digit', minute:'2-digit'})}</p>
                                </div>
                                {isCurrentUser && (
                                    <button onClick={() => setMessageToDelete(msg)} title="Supprimer le message" className="shrink-0 text-slate-400 hover:text-red-500 transition-colors p-1 rounded-full opacity-50 hover:opacity-100">
                                        <TrashIcon className="h-4 w-4" />
                                    </button>
                                )}
                            </div>

                             {isCurrentUser && <img src={sender?.avatarUrl} alt={sender?.name} className="h-8 w-8 rounded-full" />}
                        </div>
                    )
                })}
            </div>
            <div className="p-4 border-t bg-white">
                <form onSubmit={handleSendMessage} className="flex items-center space-x-3">
                    <Input 
                        type="text"
                        placeholder="Écrivez votre message..."
                        value={newMessage}
                        onChange={e => setNewMessage(e.target.value)}
                        className="flex-grow"
                        autoComplete="off"
                    />
                    <Button type="submit" size="md" disabled={!newMessage.trim()}>
                        <PaperAirplaneIcon className="h-5 w-5" />
                    </Button>
                </form>
            </div>
            <ConfirmationModal
                isOpen={!!messageToDelete}
                onClose={() => setMessageToDelete(null)}
                onConfirm={handleConfirmDeleteMessage}
                title="Supprimer le message"
                confirmText="Supprimer"
            >
                Êtes-vous sûr de vouloir supprimer ce message ? Cette action est irréversible.
            </ConfirmationModal>
        </Card>
    );
};

const AppointmentModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onSave: (appointment: Appointment) => void;
    bilan: Bilan;
    appointmentToEdit: Appointment | null;
}> = ({ isOpen, onClose, onSave, bilan, appointmentToEdit }) => {
    const [title, setTitle] = useState('');
    const [date, setDate] = useState('');
    const [time, setTime] = useState('');
    const [duration, setDuration] = useState(60);

    useEffect(() => {
        if (appointmentToEdit) {
            setTitle(appointmentToEdit.title);
            const d = appointmentToEdit.date;
            setDate(d.toISOString().split('T')[0]); // YYYY-MM-DD
            setTime(d.toTimeString().split(' ')[0].substring(0, 5)); // HH:MM
            setDuration(appointmentToEdit.durationMinutes);
        } else {
            setTitle('');
            setDate('');
            setTime('');
            setDuration(60);
        }
    }, [appointmentToEdit, isOpen]);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!date || !time) return;
        const [year, month, day] = date.split('-').map(Number);
        const [hours, minutes] = time.split(':').map(Number);
        const appointmentDate = new Date(year, month - 1, day, hours, minutes);

        const newAppointment: Appointment = {
            id: appointmentToEdit ? appointmentToEdit.id : `apt-${Date.now()}`,
            beneficiaryId: bilan.beneficiaryId,
            consultantId: bilan.consultantId,
            title,
            date: appointmentDate,
            durationMinutes: duration,
            status: 'confirmed'
        };
        onSave(newAppointment);
    };

    return (
        <Modal isOpen={isOpen} onClose={onClose} title={appointmentToEdit ? "Modifier le rendez-vous" : "Planifier un nouveau rendez-vous"}>
            <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                    <label className="block text-sm font-medium text-slate-700">Titre</label>
                    <Input type="text" value={title} onChange={e => setTitle(e.target.value)} required />
                </div>
                <div className="grid grid-cols-2 gap-4">
                    <div>
                        <label className="block text-sm font-medium text-slate-700">Date</label>
                        <Input type="date" value={date} onChange={e => setDate(e.target.value)} required />
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-slate-700">Heure</label>
                        <Input type="time" value={time} onChange={e => setTime(e.target.value)} required />
                    </div>
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700">Durée (en minutes)</label>
                    <Input type="number" value={duration} onChange={e => setDuration(parseInt(e.target.value, 10))} required min="15" />
                </div>
                 <div className="pt-4 flex justify-end space-x-2">
                    <Button type="button" variant="ghost" onClick={onClose}>Annuler</Button>
                    <Button type="submit">Enregistrer</Button>
                </div>
            </form>
        </Modal>
    );
}

const AppointmentsView: React.FC<{ bilan: Bilan; onUpdateBilan: (updatedBilan: Bilan) => void; userRole: UserRole }> = ({ bilan, onUpdateBilan, userRole }) => {
    const isConsultant = userRole === UserRole.CONSULTANT;
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [appointmentToEdit, setAppointmentToEdit] = useState<Appointment | null>(null);
    const [appointmentToDelete, setAppointmentToDelete] = useState<Appointment | null>(null);

    const handleOpenModal = (apt: Appointment | null) => {
        setAppointmentToEdit(apt);
        setIsModalOpen(true);
    };

    const handleCloseModal = () => {
        setIsModalOpen(false);
        setAppointmentToEdit(null);
    };

    const handleSaveAppointment = (appointment: Appointment) => {
        const isEditing = bilan.appointments.some(a => a.id === appointment.id);
        const updatedAppointments = isEditing
            ? bilan.appointments.map(a => a.id === appointment.id ? appointment : a)
            : [...bilan.appointments, appointment];
        
        onUpdateBilan({ ...bilan, appointments: updatedAppointments });
        handleCloseModal();
    };

    const handleConfirmDelete = () => {
        if (!appointmentToDelete) return;
        const updatedAppointments = bilan.appointments.filter(a => a.id !== appointmentToDelete.id);
        onUpdateBilan({ ...bilan, appointments: updatedAppointments });
        setAppointmentToDelete(null);
    };

    return (
        <Card>
            <div className="p-6">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-bold">Rendez-vous</h3>
                    {isConsultant && <Button variant="secondary" onClick={() => handleOpenModal(null)}><PlusIcon className="h-5 w-5 mr-2" /> Planifier un RDV</Button>}
                </div>
                <div className="space-y-4">
                    {bilan.appointments.length > 0 ? bilan.appointments.sort((a,b) => a.date.getTime() - b.date.getTime()).map(apt => (
                        <div key={apt.id} className="p-4 bg-slate-50 rounded-lg flex items-center justify-between space-x-4">
                             <div className="flex items-start space-x-4">
                                <div className="text-center bg-brand-light text-brand-dark rounded-md p-2 w-20 flex-shrink-0">
                                    <p className="text-2xl font-bold">{apt.date.getDate()}</p>
                                    <p className="text-sm uppercase">{apt.date.toLocaleString('fr-FR', { month: 'short' })}</p>
                                </div>
                                <div>
                                    <p className="font-semibold text-slate-800">{apt.title}</p>
                                    <p className="text-sm text-slate-500">
                                        {apt.date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })} - {apt.durationMinutes} minutes
                                    </p>
                                </div>
                            </div>
                            {isConsultant && (
                                <div className="flex items-center space-x-2 flex-shrink-0">
                                    <Button variant="ghost" size="sm" onClick={() => handleOpenModal(apt)} title="Modifier">
                                        <PencilIcon className="h-4 w-4" />
                                    </Button>
                                    <Button variant="ghost" size="sm" onClick={() => setAppointmentToDelete(apt)} title="Supprimer">
                                        <TrashIcon className="h-4 w-4 text-red-500" />
                                    </Button>
                                </div>
                            )}
                        </div>
                    )) : (
                        <p className="text-slate-500 text-center py-4">Aucun rendez-vous planifié pour le moment.</p>
                    )}
                </div>
            </div>
             <AppointmentModal 
                isOpen={isModalOpen}
                onClose={handleCloseModal}
                onSave={handleSaveAppointment}
                bilan={bilan}
                appointmentToEdit={appointmentToEdit}
            />
            <ConfirmationModal
                isOpen={!!appointmentToDelete}
                onClose={() => setAppointmentToDelete(null)}
                onConfirm={handleConfirmDelete}
                title="Supprimer le rendez-vous"
            >
                Êtes-vous sûr de vouloir supprimer le rendez-vous "{appointmentToDelete?.title}" ? Cette action est irréversible.
            </ConfirmationModal>
        </Card>
    )
};

const AIInsightsView: React.FC<{ bilan: Bilan; userRole: UserRole }> = ({ bilan, userRole }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [insights, setInsights] = useState<string | null>(null);

    const handleGenerate = async () => {
        setIsLoading(true);
        const result = await generateCareerInsights(bilan.assessedSkills, SKILLS);
        setInsights(result);
        setIsLoading(false);
    };

    return (
        <Card>
            <div className="p-6">
                 <h3 className="text-xl font-bold mb-2">Pistes de Réflexion (IA)</h3>
                 <p className="text-slate-600 mb-6">Explorez des pistes de métiers, de formations et de secteurs d'activité générées par l'IA sur la base des compétences évaluées.</p>
                <div className="text-center">
                    <Button onClick={handleGenerate} disabled={isLoading}>
                        {isLoading ? <Spinner size="sm" /> : (
                            <div className="flex items-center space-x-2">
                                <LightBulbIcon className="h-5 w-5" />
                                <span>Générer des pistes de réflexion</span>
                            </div>
                        )}
                    </Button>
                </div>

                {insights && (
                     <div className="mt-8">
                        <h4 className="text-lg font-semibold border-b pb-2 mb-4">Analyse de l'IA</h4>
                        <div className="prose prose-slate max-w-none p-4 bg-slate-50 rounded-md" dangerouslySetInnerHTML={{ __html: md.render(insights) }}>
                        </div>
                    </div>
                )}
            </div>
        </Card>
    );
};

const JobMarketView: React.FC<{ bilan: Bilan; onUpdateBilan: (updatedBilan: Bilan) => void }> = ({ bilan, onUpdateBilan }) => {
    const [isLoading, setIsLoading] = useState(false);

    const handleFindJobs = async () => {
        setIsLoading(true);
        const offers = await findJobOffers(bilan.assessedSkills, SKILLS);
        onUpdateBilan({ ...bilan, jobOffers: offers });
        setIsLoading(false);
    };

    const userSkillNames = useMemo(() => {
        const assessedSkillIds = new Set(bilan.assessedSkills.filter(s => s.level).map(s => s.skillId));
        return SKILLS.filter(s => assessedSkillIds.has(s.id)).map(s => s.name.toLowerCase());
    }, [bilan.assessedSkills]);

    const calculateMatchScore = (requiredSkills: string[]) => {
        if (requiredSkills.length === 0) return 100;
        const matchedSkills = requiredSkills.filter(reqSkill => userSkillNames.includes(reqSkill.toLowerCase()));
        return (matchedSkills.length / requiredSkills.length) * 100;
    };

    return (
        <Card>
            <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Exploration du Marché du Travail</h3>
                <p className="text-slate-600 mb-6">Utilisez l'IA pour rechercher des offres d'emploi (simulation via France Travail) correspondant à votre profil de compétences.</p>
                <div className="text-center">
                    <Button onClick={handleFindJobs} disabled={isLoading}>
                        {isLoading ? <Spinner size="sm" /> : (
                            <div className="flex items-center space-x-2">
                                <MagnifyingGlassIcon className="h-5 w-5" />
                                <span>{bilan.jobOffers ? 'Relancer la recherche' : 'Lancer la recherche d\'offres'}</span>
                            </div>
                        )}
                    </Button>
                </div>
                
                {isLoading && <div className="mt-8 flex justify-center"><Spinner /></div>}

                {!isLoading && bilan.jobOffers && (
                    <div className="mt-8 space-y-6">
                        {bilan.jobOffers.length > 0 ? bilan.jobOffers.map(offer => {
                            const matchScore = calculateMatchScore(offer.requiredSkills);
                            return (
                                <Card key={offer.id} className="p-4 border">
                                    <h4 className="font-bold text-lg text-brand-dark">{offer.title}</h4>
                                    <p className="font-semibold text-slate-700">{offer.company}</p>
                                    <p className="text-sm text-slate-500">{offer.location} - {offer.contractType}</p>
                                    <p className="text-sm text-slate-600 my-3">{offer.description}</p>
                                    
                                    <div className="my-4">
                                        <div className="flex justify-between items-center mb-1">
                                            <span className="text-sm font-medium text-slate-600">Matching des compétences</span>
                                            <span className="text-sm font-bold text-brand-primary">{Math.round(matchScore)}%</span>
                                        </div>
                                        <ProgressBar value={matchScore} />
                                    </div>

                                    <div>
                                        <h5 className="font-semibold text-sm mb-2">Compétences requises :</h5>
                                        <div className="flex flex-wrap gap-2">
                                            {offer.requiredSkills.map(skill => {
                                                const hasSkill = userSkillNames.includes(skill.toLowerCase());
                                                return (
                                                    <span key={skill} className={`text-xs font-medium px-2 py-1 rounded-full ${hasSkill ? 'bg-green-100 text-green-800' : 'bg-slate-100 text-slate-600'}`}>{skill}</span>
                                                )
                                            })}
                                        </div>
                                    </div>
                                </Card>
                            )
                        }) : <p className="text-center text-slate-500 py-6">Aucune offre correspondante n'a été trouvée pour le moment.</p>}
                    </div>
                )}
            </div>
        </Card>
    );
};


const QualiopiView: React.FC<{ bilan: Bilan; onUpdateBilan: (updatedBilan: Bilan) => void; userRole: UserRole }> = ({ bilan, onUpdateBilan, userRole }) => {
    const isConsultant = userRole === UserRole.CONSULTANT;

    const handleStatusChange = (taskId: string, status: QualiopiStatus) => {
        const updatedTasks = bilan.qualiopiTasks.map(task => 
            task.id === taskId ? { ...task, status } : task
        );
        onUpdateBilan({ ...bilan, qualiopiTasks: updatedTasks });
    };

    const statusColors: { [key in QualiopiStatus]: string } = {
        [QualiopiStatus.TODO]: 'bg-slate-200 text-slate-800',
        [QualiopiStatus.IN_PROGRESS]: 'bg-yellow-200 text-yellow-800',
        [QualiopiStatus.DONE]: 'bg-green-200 text-green-800',
    };
    
    return (
        <Card>
            <div className="p-6">
                <h3 className="text-xl font-bold mb-4">Suivi de Conformité Qualiopi</h3>
                <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Indicateur</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {bilan.qualiopiTasks.map(task => (
                          <tr key={task.id}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{task.indicator}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{task.description}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {isConsultant ? (
                                <select 
                                    value={task.status}
                                    onChange={(e) => handleStatusChange(task.id, e.target.value as QualiopiStatus)}
                                    className={`rounded-md border-gray-300 shadow-sm focus:border-brand-primary focus:ring-brand-primary sm:text-sm ${statusColors[task.status]}`}
                                >
                                    {Object.values(QualiopiStatus).map(s => <option key={s} value={s}>{s}</option>)}
                                </select>
                              ) : (
                                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${statusColors[task.status]}`}>
                                  {task.status}
                                </span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                </div>
            </div>
        </Card>
    );
};

const UploadDocumentModal: React.FC<{
    isOpen: boolean;
    onClose: () => void;
    onUpload: (document: Omit<Document, 'id' | 'uploadDate' | 'uploaderId'>) => void;
}> = ({ isOpen, onClose, onUpload }) => {
    const [name, setName] = useState('');
    const [fileType, setFileType] = useState<'pdf' | 'docx' | 'png' | 'jpeg'>('pdf');
    const [sizeKB, setSizeKB] = useState(100);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (!name.trim()) {
            alert("Veuillez entrer un nom de fichier.");
            return;
        }
        onUpload({ name, fileType, sizeKB });
        onClose();
    };
    
    useEffect(() => {
        if (!isOpen) {
            setName('');
            setFileType('pdf');
            setSizeKB(100);
        }
    }, [isOpen]);

    return (
        <Modal isOpen={isOpen} onClose={onClose} title="Transférer un document">
            <form onSubmit={handleSubmit} className="space-y-4">
                <p className="text-sm text-slate-600">Ceci est une simulation. Dans une application réelle, vous sélectionneriez un fichier depuis votre ordinateur.</p>
                <div>
                    <label className="block text-sm font-medium text-slate-700">Nom du fichier (avec extension)</label>
                    <Input type="text" value={name} onChange={e => setName(e.target.value)} required placeholder="Ex: mon_cv.pdf" />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700">Type de fichier (simulé)</label>
                    <select value={fileType} onChange={e => setFileType(e.target.value as any)} className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-brand-primary focus:ring-brand-primary sm:text-sm">
                        <option value="pdf">PDF</option>
                        <option value="docx">DOCX</option>
                        <option value="png">PNG</option>
                        <option value="jpeg">JPEG</option>
                    </select>
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-700">Taille du fichier (en Ko, simulé)</label>
                    <Input type="number" value={sizeKB} onChange={e => setSizeKB(parseInt(e.target.value, 10))} required min="1" />
                </div>
                 <div className="pt-4 flex justify-end space-x-2">
                    <Button type="button" variant="ghost" onClick={onClose}>Annuler</Button>
                    <Button type="submit">Transférer</Button>
                </div>
            </form>
        </Modal>
    );
};

const DocumentsView: React.FC<{ bilan: Bilan; onUpdateBilan: (updatedBilan: Bilan) => void; currentUser: User }> = ({ bilan, onUpdateBilan, currentUser }) => {
    const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
    const [documentToDelete, setDocumentToDelete] = useState<Document | null>(null);

    const handleUpload = (docData: Omit<Document, 'id' | 'uploadDate' | 'uploaderId'>) => {
        const newDocument: Document = {
            ...docData,
            id: `doc-${Date.now()}`,
            uploadDate: new Date(),
            uploaderId: currentUser.id,
        };
        const updatedDocuments = [...(bilan.documents || []), newDocument];
        onUpdateBilan({ ...bilan, documents: updatedDocuments });
    };

    const handleConfirmDelete = () => {
        if (!documentToDelete) return;
        const updatedDocuments = bilan.documents.filter(d => d.id !== documentToDelete.id);
        onUpdateBilan({ ...bilan, documents: updatedDocuments });
        setDocumentToDelete(null);
    };
    
    const getFileIcon = (fileType: string) => {
        return <DocumentTextIcon className="h-8 w-8 text-slate-500" />;
    };

    return (
        <Card>
            <div className="p-6">
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-bold">Documents Partagés</h3>
                    <Button variant="secondary" onClick={() => setIsUploadModalOpen(true)}>
                        <ArrowUpTrayIcon className="h-5 w-5 mr-2" /> Transférer un document
                    </Button>
                </div>
                <div className="space-y-3">
                    {(bilan.documents || []).length > 0 ? (bilan.documents || []).sort((a,b) => b.uploadDate.getTime() - a.uploadDate.getTime()).map(doc => {
                        const uploader = USERS.find(u => u.id === doc.uploaderId);
                        return (
                            <div key={doc.id} className="p-3 bg-slate-50 rounded-lg flex items-center justify-between space-x-4 hover:bg-slate-100 transition-colors">
                                <div className="flex items-center space-x-4 flex-grow">
                                    {getFileIcon(doc.fileType)}
                                    <div className="flex-grow">
                                        <p className="font-semibold text-slate-800 break-all">{doc.name}</p>
                                        <p className="text-xs text-slate-500">
                                            Par {uploader?.name} le {doc.uploadDate.toLocaleDateString('fr-FR')} - {doc.sizeKB} Ko
                                        </p>
                                    </div>
                                </div>
                                <div className="flex items-center space-x-2 flex-shrink-0">
                                    <Button variant="ghost" size="sm" title="Télécharger">
                                        <DocumentArrowDownIcon className="h-5 w-5" />
                                    </Button>
                                    {doc.uploaderId === currentUser.id && (
                                        <Button variant="ghost" size="sm" onClick={() => setDocumentToDelete(doc)} title="Supprimer">
                                            <TrashIcon className="h-5 w-5 text-red-500" />
                                        </Button>
                                    )}
                                </div>
                            </div>
                        )
                    }) : (
                        <p className="text-slate-500 text-center py-8">Aucun document n'a été partagé pour ce bilan.</p>
                    )}
                </div>
            </div>
            <UploadDocumentModal 
                isOpen={isUploadModalOpen} 
                onClose={() => setIsUploadModalOpen(false)}
                onUpload={handleUpload}
            />
            <ConfirmationModal
                isOpen={!!documentToDelete}
                onClose={() => setDocumentToDelete(null)}
                onConfirm={handleConfirmDelete}
                title="Supprimer le document"
            >
                Êtes-vous sûr de vouloir supprimer le document "{documentToDelete?.name}" ? Cette action est irréversible.
            </ConfirmationModal>
        </Card>
    )
};

const BilanDetailView: React.FC<{ bilan: Bilan; onBack: () => void; onUpdateBilan: (updatedBilan: Bilan) => void; currentUser: User; onRequestBilanDeletion: (bilan: Bilan) => void; }> = ({ bilan, onBack, onUpdateBilan, currentUser, onRequestBilanDeletion }) => {
    const beneficiary = USERS.find(u => u.id === bilan.beneficiaryId);
    const [activeTab, setActiveTab] = useState('skills');

    const tabs: { id: string, label: string, icon: React.ReactNode, roles: UserRole[] }[] = [
        { id: 'skills', label: 'Compétences', icon: <UserCircleIcon className="h-5 w-5" />, roles: [UserRole.BENEFICIARY, UserRole.CONSULTANT, UserRole.ADMIN] },
        { id: 'insights', label: 'IA Insights', icon: <LightBulbIcon className="h-5 w-5" />, roles: [UserRole.BENEFICIARY, UserRole.CONSULTANT, UserRole.ADMIN] },
        { id: 'market', label: 'Explorer le Marché', icon: <MagnifyingGlassIcon className="h-5 w-5" />, roles: [UserRole.BENEFICIARY, UserRole.CONSULTANT, UserRole.ADMIN] },
        { id: 'synthesis', label: 'Synthèse', icon: <DocumentTextIcon className="h-5 w-5" />, roles: [UserRole.BENEFICIARY, UserRole.CONSULTANT, UserRole.ADMIN] },
        { id: 'documents', label: 'Documents', icon: <FolderIcon className="h-5 w-5" />, roles: [UserRole.BENEFICIARY, UserRole.CONSULTANT] },
        { id: 'messages', label: 'Messages', icon: <ChatBubbleLeftRightIcon className="h-5 w-5" />, roles: [UserRole.BENEFICIARY, UserRole.CONSULTANT] },
        { id: 'appointments', label: 'Rendez-vous', icon: <CalendarDaysIcon className="h-5 w-5" />, roles: [UserRole.BENEFICIARY, UserRole.CONSULTANT] },
        { id: 'qualiopi', label: 'Qualiopi', icon: <ShieldCheckIcon className="h-5 w-5" />, roles: [UserRole.CONSULTANT, UserRole.ADMIN] },
    ];

    const availableTabs = tabs.filter(tab => tab.roles.includes(currentUser.role));
    
    return (
        <div className="space-y-6">
            <div>
                <Button onClick={onBack} variant="secondary" size="sm">
                    &larr; Retour
                </Button>
            </div>
            <Card className="p-6">
                <div className="flex justify-between items-center">
                    <div>
                        <h2 className="text-2xl font-bold">Bilan de {beneficiary?.name}</h2>
                        <p className="text-slate-500">Statut: {bilan.status}</p>
                    </div>
                    {currentUser.role === UserRole.ADMIN && (
                         <Button variant="danger" size="sm" onClick={() => onRequestBilanDeletion(bilan)}>
                            <TrashIcon className="h-4 w-4 mr-2" />
                            Supprimer le bilan
                        </Button>
                    )}
                </div>
            </Card>

            <Tabs tabs={availableTabs} activeTab={activeTab} onTabClick={setActiveTab} />
            
            <div className="mt-6">
                {activeTab === 'skills' && <SkillsAssessment bilan={bilan} onUpdateBilan={onUpdateBilan} userRole={currentUser.role} />}
                {activeTab === 'synthesis' && <SynthesisGenerator bilan={bilan} onUpdateBilan={onUpdateBilan} userRole={currentUser.role} />}
                {activeTab === 'documents' && <DocumentsView bilan={bilan} onUpdateBilan={onUpdateBilan} currentUser={currentUser} />}
                {activeTab === 'messages' && <MessagingView bilan={bilan} onUpdateBilan={onUpdateBilan} currentUser={currentUser} />}
                {activeTab === 'appointments' && <AppointmentsView bilan={bilan} onUpdateBilan={onUpdateBilan} userRole={currentUser.role} />}
                {activeTab === 'insights' && <AIInsightsView bilan={bilan} userRole={currentUser.role} />}
                {activeTab === 'market' && <JobMarketView bilan={bilan} onUpdateBilan={onUpdateBilan} />}
                {activeTab === 'qualiopi' && <QualiopiView bilan={bilan} onUpdateBilan={onUpdateBilan} userRole={currentUser.role} />}
            </div>
        </div>
    );
};

// --- DASHBOARD COMPONENTS ---

const BeneficiaryDashboard: React.FC<{ bilans: Bilan[], onSelectBilan: (id: string) => void, user: User }> = ({ bilans, onSelectBilan, user }) => {
    const bilan = bilans[0]; // Assuming beneficiary has only one active bilan
    if(!bilan) return <p>Vous n'avez pas encore de bilan de compétences actif.</p>;

    const nextAppointment = bilan.appointments.filter(a => a.date > new Date()).sort((a,b) => a.date.getTime() - b.date.getTime())[0];
    const unassessedSkills = bilan.assessedSkills.filter(s => !s.level || !s.interest).length;

    return (
        <div>
            <h2 className="text-3xl font-bold mb-6">Bonjour, {user.name.split(' ')[0]} !</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-2">
                    <BilanCard bilan={bilan} userRole={user.role} onSelect={() => onSelectBilan(bilan.id)} />
                </div>
                <Card className="p-6">
                    <h3 className="font-bold text-lg mb-4">Prochaines étapes</h3>
                    <ul className="space-y-3 text-sm">
                        {nextAppointment && (
                             <li className="flex items-start space-x-3">
                                <CalendarDaysIcon className="h-5 w-5 text-brand-primary mt-0.5"/>
                                <span>Prochain RDV le <span className="font-semibold">{nextAppointment.date.toLocaleDateString('fr-FR')}</span> avec votre consultant.</span>
                            </li>
                        )}
                        {unassessedSkills > 0 && (
                            <li className="flex items-start space-x-3">
                                <UserCircleIcon className="h-5 w-5 text-brand-primary mt-0.5"/>
                                <span>Complétez votre auto-évaluation pour les <span className="font-semibold">{unassessedSkills} compétence{unassessedSkills > 1 ? 's' : ''}</span> restantes.</span>
                            </li>
                        )}
                         {!nextAppointment && unassessedSkills === 0 && (
                            <li className="flex items-start space-x-3">
                                <CheckCircleIcon className="h-5 w-5 text-green-50